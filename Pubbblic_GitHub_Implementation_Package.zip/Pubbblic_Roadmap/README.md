# Pubbblic GitHub Projects launch package

This package contains **13 epics + 125 detailed implementation issues = 138 issues** with directed dependencies, acceptance criteria, staging verification checklists, and hard production gates.

The issues and GitHub Project have **not** been created in a remote repository. This is a ready-to-run, reversible-first bootstrap package. No customer publishing is triggered by importing it.

## Files

- `ROADMAP.md`: product execution plan and critical paths.
- `ARCHITECTURE.md`: hybrid accounts, domain model, state machines and security boundaries.
- `GATES.md`: launch checklist and ownership signoffs.
- `issues.json`: machine-readable canonical backlog, topologically sorted child issues.
- `issues.csv`: tabular copy for review or import planning.
- `dependencies.csv`: explicit directed dependency graph (blocked issue -> blocking issue).
- `publisher_candidates.csv`: 19 candidate sites, no presumption of authorization, per-site audit issue IDs.
- `issue_specs/`: 138 complete Markdown issue descriptions.
- `bootstrap_github.py`: GitHub CLI automation to create/link repo, project, milestones, labels, epics and dependent sub-issues.
- `PROJECT_CONFIGURATION.md`: project fields, saved view recipes, role ownership and delivery states.
- `TEST_MATRIX.md`: 30 E2E, compliance, security and operational release acceptance scenarios.
- `validate_backlog.py`: offline issue/dependency/CSV consistency validation.

## Using it in GitHub Codespaces

1. Upload/unzip the package into your Codespace or local working directory with Python 3.10+ and GitHub CLI **v2.94.0 or later** installed (for native parent/sub-issue and issue dependency flags).
2. Authenticate with the desired GitHub owner; `gh auth status`. For Projects, grant the `project` OAuth scope using `gh auth refresh -s project` if supported, or use an appropriately scoped GitHub token.
3. Preview without writes:

```bash
python3 bootstrap_github.py --owner ByMarkAllan
```

4. Execute against the **explicitly selected owner** (switch `ByMarkAllan` to `QaloriHQ` if desired):

```bash
python3 bootstrap_github.py --owner ByMarkAllan --apply
```

The script defaults to a private repo named `pubbblic-platform`. To only use an already-created repo, add `--existing-only`; to create just the first few epics for a pilot, add `--limit 5` (subsequent execution safely resumes).

**The script never uses user passwords, bypasses restrictions, or starts publisher automation.** GitHub permissions and organization policies still govern repository/project creation.

## How import works

- Creates repo if not present; otherwise reuses it without overwriting files.
- Creates/reuses GitHub Project `Pubbblic — Product Roadmap`, links repo and adds Priority/Wave/Risk/Gate/Workstream/Delivery Stage fields.
- Creates/reuses release milestones and labels.
- Creates parent epic issues, then dependency-ordered tasks with GitHub native sub-issues and blocked-by relations.
- Creates issues with structured acceptance criteria, verification instructions, risk ratings and current gate IDs.
- Adds issues to Projects and assigns custom fields; reruns look for issue ID prefixes to avoid duplicate issues and preserve already-managed delivery stages.

The official GitHub CLI supports `gh project create`, `gh project item-add`, `gh project field-create`, and `gh issue create --parent/--blocked-by` in recent versions. Review `PROJECT_CONFIGURATION.md` to configure saved views in the GitHub web UI; the script does not create those views.

Validate the package first: `python3 validate_backlog.py`. Only `--apply` mutates GitHub; a preview is entirely offline.

## Risks / approvals

- Pilot publisher written permission is a hard dependency (`PUB-05.07`). The 19 listed sites are *candidates*, not approved automation destinations.
- No production payment processing or external publishing before `PUB-12.09` owner approval.
- Do not claim a GitHub Project or issues were created until script success shows verified URLs.
