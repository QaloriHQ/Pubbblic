# Pubbblic production and release gates

Each gate is a **hard acceptance checkpoint**, not simply a GitHub status. Attach verifiable evidence to the canonical gate issue/Project. Gate owners can withhold approval. The owner authorizes all changes to launch scope and the final production activation.

| Gate | Minimum go/no-go evidence | Primary accountable roles | Blocks |
|---|---|---|---|
| G1: Foundation | CI protected; staging/prod separated; Supabase auth and RLS negative tests; secrets/backup/rollback baseline | Engineering + Security | Sensitive customer data and feature promotion |
| G2: Authoring + editorial | Canonical schema, immutable approved snapshots, review roles, issuer verification, corrections, content policy, accessibility | Product + Editorial + Legal | Publishing unreviewed content |
| G3: Publisher permissions | Dated audit of 19 candidates; **written authorization** for each live automated path; clear hybrid account rights; effective fees and rate limits; kill switches | Partnerships + Legal + Security | Any unauthorized publisher submission |
| G4: Distribution pilot | At least one explicitly authorized end-to-end publisher path; browser sandbox; safe queue/idempotency; verified live placement evidence; 20 controlled scenarios (live or simulated where appropriate); no duplicate submissions | Engineering + QA + Partnerships | Customer-facing automated distribution |
| G5: Commercial MVP | Stripe test/live separation; signed webhooks; atomic credits; refunds; accounting; honest package claims; reports distinguish submission from verified publication | Finance + Product + Legal | Production payments and paid distribution |
| G6: Production authorization | Zero unresolved P0 blockers and critical/high exploitable findings; tested backup restore; resilient failure recovery; accessibility audit; incident runbooks; cost caps; explicit owner signoff | Owner + Engineering + QA + Security + Legal | Public launch / production flags |
| G7: Scale | New integrations reauthorize; service SLOs meet targets; quality review and verified reporting stay intact | Product + Partnerships + Operations | Adding publishers or AI claims at scale |

## Production acceptance checklist

- [ ] `PUB-12.09` explicit owner signoff recorded with dated G1–G6 links.
- [ ] Production publisher automation has no connector without an approved, current authorization record.
- [ ] Managed partner credentials and connected-customer credentials are isolated; assisted tasks are labeled manual.
- [ ] No bypass of CAPTCHA/MFA/anti-bot controls; manual handoff is safe and supported.
- [ ] Two live external submissions cannot be produced by replaying a queue task or webhook.
- [ ] Every verified placement is backed by live URL plus identity/content validation and reviewable evidence.
- [ ] Paid offerings accurately disclose editorial discretion, publisher fees, refunds and limitations.
- [ ] Tenant isolation, audit logs, backup restore, kill switch, incident management and monitoring pass tests.
- [ ] No unresolved critical/high vulnerabilities; dependency risk decisions documented.
- [ ] Deployment rollback and app/worker feature flags rehearsed in staging.

## Proposed operational SLOs (targets, not currently measured)

- API availability: **99.9%** monthly for primary customer endpoints after launch.
- Queued job durability: **no acknowledged job loss** during worker restarts or queue lease recovery.
- Duplicate external submission: **zero in verified pilot and staging regression suites**.
- Unauthorized automated publisher submissions: **zero**.
- Verified-publication evidence integrity: **100% of sampled verified placement claims** have valid corroborating source URL + match record.
- Financial event reconciliation: **100% of sampled paid orders** reconcile to credits, ledger and Stripe references.
- Recovery targets: set based on chosen Supabase plan, restore design and incident budget **before** setting an RTO/RPO contractual promise.

These are proposed acceptance criteria, not existing service performance or publisher guarantees.
