# Pubbblic — end-to-end acceptance and risk test matrix

These scenarios are mandatory examples for G1–G6 evidence. Use mocks/staging for third-party actions unless the test publisher expressly authorizes a controlled live submission. Every test records an ID, environment, actor, fixture, expected result, result URL and verifier.

| Test ID | Scenario | Expected result | Gate |
|---|---|---|---|
| T01 | New user email signup, verification, session revocation | Invalid sessions rejected, no role escalation | G1 |
| T02 | User in organization A requests B's drafts | RLS denies read, logs contain no sensitive values | G1 |
| T03 | User with editor role attempts owner-only publisher connection change | Denied server-side | G1 |
| T04 | Staging API points to production Supabase by mistake | Deploy validation fails closed | G1 |
| T05 | Restore database backup into isolated validation environment | Data and RLS policy integrity pass | G1/G6 |
| T06 | Autosave conflicting changes from two sessions | No silent loss; version conflict/recovery visible | G2 |
| T07 | Submit release with missing contact, invalid category or unsupported assets | Descriptive validation; no dispatch | G2 |
| T08 | Modify release after approval | Creates new draft revision; approved snapshot immutable | G2 |
| T09 | Reviewer rejects unsupported financial or medical claim | Returns to changes requested/rejected; no dispatch | G2 |
| T10 | Unverified issuer schedules external distribution | Blocked until verified | G2/G3 |
| T11 | Publisher does not permit browser automation | Browser connector remains disabled; assisted workflow offered | G3 |
| T12 | Connected customer revokes authorization | New automated jobs blocked; credentials disabled | G3 |
| T13 | Managed partner changes terms or rate limit | Connector disabled or adjusted until reviewed | G3 |
| T14 | Preview destination-specific plan with per-site cost/mode | Customer sees transparent price, expected outcomes and limitations | G3/G5 |
| T15 | Enqueue approved release with publisher embargo/timezone | Never submitted before specified eligible time | G4 |
| T16 | Duplicate queue delivery and two simultaneous workers | Idempotency lease prevents duplicate external action | G4 |
| T17 | Worker crashes after uncertain external confirmation | State becomes unknown_outcome; reconcile before retry | G4 |
| T18 | CAPTCHA/MFA or anti-bot challenge appears | Human intervention state; no bypass | G4 |
| T19 | Publisher returns submitted confirmation but no public URL | Submitted or verification_pending, not published_verified | G4 |
| T20 | Verified URL contains different organization/release text | Verification rejects mismatch | G4 |
| T21 | Published URL later removed or redirects | Evidence updated and customer notified according to policy | G4/G5 |
| T22 | Publisher rejects submission | Rejection reflected without fictitious placement claim | G4/G5 |
| T23 | Stripe webhook duplicated/out of order | Exactly one ledger entitlement and accurate reconciliation | G5 |
| T24 | Partial publisher failure, cancellation and refund | Contractual refund/credit policy honored, no double spend | G5 |
| T25 | Mixpanel blocked by user consent state | No prohibited tracking; operations/commerce still work | G5 |
| T26 | Analytics shows estimated vs publisher-provided vs verified values | Source, confidence and caveats remain explicit | G5 |
| T27 | Browser visits hostile/injected third-party page | Worker network/file/secrets controls block exfiltration | G6 |
| T28 | Invalid/expired production authorization for publisher | Live connector kill switch prevents execution | G6 |
| T29 | Emergency release rollback and queue pause | Production rollback/kill switch demonstrated, no job loss | G6 |
| T30 | Full happy-path: create → review → approved pilot → live URL → invoice → report | End-to-end audit trace and human signoffs | G6 |

## Evidence instructions

- In every issue, link tests, build commit, CI run, staging deployment, fixture IDs, and human verifier result.
- Use redacted screenshots, structured logs, and link-confirmation hashes rather than saving third-party cookies/passwords.
- Mark test as **simulated** vs **authorized live**, not both.
- For publisher site audits, document current public endpoint and terms, explicit permission/response, account model, rate/cost restrictions, editorial policy, available test path, and signoff date.

## Fail-closed conditions

Any of the following blocks external production distribution until corrected: absent permission, leaked credentials, uncertain duplicate-submission state, failed tenant isolation, unverified release identity, invoice/entitlement mismatch, unavailable stop control, or a material discrepancy in reported publication evidence.
