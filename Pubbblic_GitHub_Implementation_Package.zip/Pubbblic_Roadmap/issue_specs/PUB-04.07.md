# [PUB-04.07] Create editorial quality UAT suite

## Objective
Build fixtures for legitimate announcements, exaggerated claims, impersonation, placeholder content and correction edge cases.

## Acceptance criteria
- [ ] Each rejection/hold case has a regression test.
- [ ] Editorial decisions are reproducible from stored version and policy revision.
- [ ] Release approval cannot be bypassed through direct API calls.

## Dependencies (blocked by)
- PUB-04.03
- PUB-04.05

## Execution metadata
- Epic: PUB-04
- Work wave: W3
- Release gate: G2
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
