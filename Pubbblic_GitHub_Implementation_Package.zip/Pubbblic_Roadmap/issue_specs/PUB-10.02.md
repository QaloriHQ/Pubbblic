# [PUB-10.02] Instrument critical release conversion funnel

## Objective
Implement events with server-side reconciliation of account, editor, submission, payment and verified placement milestones.

## Acceptance criteria
- [ ] Event identity stitching avoids double-counting anonymous/authenticated users.
- [ ] Events are tracked from real state transitions rather than button clicks alone.
- [ ] Staging validation confirms expected counts against database records.

## Dependencies (blocked by)
- PUB-10.01
- PUB-06.01

## Execution metadata
- Epic: PUB-10
- Work wave: W5
- Release gate: G5
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
