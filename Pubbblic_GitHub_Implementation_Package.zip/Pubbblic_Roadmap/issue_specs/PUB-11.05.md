# [PUB-11.05] Create vulnerability, dependency and browser patch cadence

## Objective
Implement security advisories, dependency scanning, Chromium release process and third-party SDK updates.

## Acceptance criteria
- [ ] Known critical vulnerabilities block production promotion until remediated or explicitly risk-accepted.
- [ ] Worker images are rebuilt and smoke-tested on a defined schedule.
- [ ] SBOM and dependency audit artifacts are retained.

## Dependencies (blocked by)
- PUB-00.05
- PUB-07.02

## Execution metadata
- Epic: PUB-11
- Work wave: W6
- Release gate: G6
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
