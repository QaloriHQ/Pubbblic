# [PUB-05.04] Design permissions and connection onboarding

## Objective
Create connected-account onboarding with secure OAuth/API key flows where supported and no credential scraping.

## Acceptance criteria
- [ ] Customer authorization and permissions are visible before connection.
- [ ] Password-based connectors are only enabled if explicitly permitted and securely stored.
- [ ] Connection verification, revocation and expiry states work end to end.

## Dependencies (blocked by)
- PUB-05.02
- PUB-00.08

## Execution metadata
- Epic: PUB-05
- Work wave: W3
- Release gate: G3
- Priority: P0
- Estimate: M (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
