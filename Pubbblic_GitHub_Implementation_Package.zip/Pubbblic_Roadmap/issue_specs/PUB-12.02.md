# [PUB-12.02] Run tenant isolation and auth penetration review

## Objective
Assess sessions, RLS, CSRF/XSS, role escalation, credential boundaries and direct API misuse.

## Acceptance criteria
- [ ] No unresolved critical/high exploit path to customer or publisher data remains.
- [ ] Negative RLS tests and admin elevation controls pass.
- [ ] Findings and remediation evidence are attached to release checklist.

## Dependencies (blocked by)
- PUB-02.08
- PUB-07.08
- PUB-11.04

## Execution metadata
- Epic: PUB-12
- Work wave: W6
- Release gate: G6
- Priority: P0
- Estimate: M (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
