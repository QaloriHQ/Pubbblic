# [PUB-05.28] Consolidate candidate publisher audit and MVP shortlist

## Objective
Review all 19 candidate audit records, select viable authorized partners, document publisher coverage and lock the initial live network configuration.

## Acceptance criteria
- [ ] All 19 candidate audits have dated evidence and assigned owners; unknown permission remains disabled.
- [ ] MVP publisher shortlist identifies allowed automated versus managed versus assisted submission explicitly.
- [ ] Legal, security and partnerships jointly approve live connector/credential scope and publication claims.

## Dependencies (blocked by)
- PUB-05.09
- PUB-05.10
- PUB-05.11
- PUB-05.12
- PUB-05.13
- PUB-05.14
- PUB-05.15
- PUB-05.16
- PUB-05.17
- PUB-05.18
- PUB-05.19
- PUB-05.20
- PUB-05.21
- PUB-05.22
- PUB-05.23
- PUB-05.24
- PUB-05.25
- PUB-05.26
- PUB-05.27
- PUB-05.07

## Execution metadata
- Epic: PUB-05
- Work wave: W3
- Release gate: G3
- Priority: P0
- Estimate: M (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
