# [PUB-07.03] Build secrets and session broker

## Objective
Create encrypted, short-lived account access with scoped retrieval, rotation, expiry and connection revocation.

## Acceptance criteria
- [ ] Secrets are never placed in issue logs, screenshots or browser error traces.
- [ ] No account can be accessed by a different organization.
- [ ] Revoked authorization immediately prevents new executions.

## Dependencies (blocked by)
- PUB-05.04
- PUB-07.02

## Execution metadata
- Epic: PUB-07
- Work wave: W4
- Release gate: G4
- Priority: P0
- Estimate: M (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
