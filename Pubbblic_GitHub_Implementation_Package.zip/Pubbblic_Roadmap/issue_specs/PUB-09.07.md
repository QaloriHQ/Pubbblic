# [PUB-09.07] Add taxes, billing identity and compliance review

## Objective
Validate jurisdiction and tax handling, invoice data, platform terms and refund communications with counsel/accounting.

## Acceptance criteria
- [ ] Sales tax collection obligations are documented for initial markets.
- [ ] Billing identities and tax metadata are protected by least privilege.
- [ ] Pricing/terms are reviewed before accepting production payments.

## Dependencies (blocked by)
- PUB-09.02
- PUB-01.06

## Execution metadata
- Epic: PUB-09
- Work wave: W5
- Release gate: G5
- Priority: P0
- Estimate: M (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
