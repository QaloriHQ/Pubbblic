# [PUB-09.06] Define partial failure, cancellation and refund policies

## Objective
Build financial and operational resolution rules for editorial rejections, failed deliveries and user cancellation.

## Acceptance criteria
- [ ] Customer-facing policy distinguishes attempted, accepted and verified outcomes.
- [ ] Refund eligibility is deterministic with an auditable override.
- [ ] Finance reconciliation handles partial delivery without losing original order history.

## Dependencies (blocked by)
- PUB-09.04
- PUB-08.06

## Execution metadata
- Epic: PUB-09
- Work wave: W5
- Release gate: G5
- Priority: P0
- Estimate: M (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
