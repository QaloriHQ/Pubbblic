# [PUB-09.05] Implement credits, usage and agency billing

## Objective
Allow agency accounts to allocate pre-purchased release credits across permitted clients and view usage.

## Acceptance criteria
- [ ] Credit debits are atomic and never double-applied.
- [ ] Usage reconciles to campaign destinations and publisher expenses.
- [ ] Billing roles can view invoices without editorial privilege.

## Dependencies (blocked by)
- PUB-09.03
- PUB-02.05

## Execution metadata
- Epic: PUB-09
- Work wave: W5
- Release gate: G5
- Priority: P1
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
