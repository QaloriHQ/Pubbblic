# [PUB-12.05] Verify backups, restore and disaster recovery

## Objective
Conduct tested restore of staging database/storage, simulate lost worker and validate credential-revocation process.

## Acceptance criteria
- [ ] Recovery objectives are defined and a rehearsal meets them.
- [ ] Restored state retains submission evidence and immutable ledgers.
- [ ] Secrets are rotated when simulating compromise.

## Dependencies (blocked by)
- PUB-00.04
- PUB-11.04

## Execution metadata
- Epic: PUB-12
- Work wave: W6
- Release gate: G6
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
