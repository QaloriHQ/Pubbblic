# [PUB-11.08] Create abuse prevention and operational rate limiting

## Objective
Apply signup anti-abuse controls, velocity limits, suspicious release patterns and fraud escalation.

## Acceptance criteria
- [ ] Bad actors cannot mass create campaigns without throttling and checks.
- [ ] False positives support operator review/appeal.
- [ ] Controls have metrics, alerts and auditable overrides.

## Dependencies (blocked by)
- PUB-04.06
- PUB-02.01

## Execution metadata
- Epic: PUB-11
- Work wave: W6
- Release gate: G6
- Priority: P0
- Estimate: M (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
