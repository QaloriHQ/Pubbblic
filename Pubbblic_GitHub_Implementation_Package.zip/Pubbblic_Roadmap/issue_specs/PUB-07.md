# [PUB-07] Publisher connector framework and Puppeteer pilot

## Outcome
Implement adapter contracts with secure, authorized API/browser/assisted execution and deterministic verification signals.
## Release gate
G4
## Child issues (implementation contracts)
- [ ] PUB-07.01: Define typed publisher adapter SDK
- [ ] PUB-07.02: Provision isolated Puppeteer worker runtime
- [ ] PUB-07.03: Build secrets and session broker
- [ ] PUB-07.04: Implement approved browser connector pilot
- [ ] PUB-07.05: Implement API/partner connector reference
- [ ] PUB-07.06: Build assisted submission workspace
- [ ] PUB-07.07: Implement connector selector/version drift alerts
- [ ] PUB-07.08: Harden browser worker against untrusted content
- [ ] PUB-07.09: Run authorized end-to-end publisher pilot

## Epic completion conditions
- [ ] All P0 children passed acceptance and merged to staging
- [ ] Evidence and security/privacy review recorded in child issues
- [ ] Relevant release gate explicitly approved; production changes not implied
- [ ] Risks, follow-on tasks and known limitations documented

**Ownership:** Product approval is required for scope changes and every production authorization.
