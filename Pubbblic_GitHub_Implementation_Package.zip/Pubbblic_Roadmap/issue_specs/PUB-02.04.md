# [PUB-02.04] Apply tenant RLS across all product data

## Objective
Implement and test Row Level Security for organizations, releases, campaigns, accounts, payments and analytics records.

## Acceptance criteria
- [ ] Cross-tenant reads/writes are rejected under user tokens.
- [ ] Service-role pathways are narrowly scoped and auditable.
- [ ] Automated RLS regression suite covers all customer-owned tables.

## Dependencies (blocked by)
- PUB-02.03

## Execution metadata
- Epic: PUB-02
- Work wave: W2
- Release gate: G1
- Priority: P0
- Estimate: L (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
