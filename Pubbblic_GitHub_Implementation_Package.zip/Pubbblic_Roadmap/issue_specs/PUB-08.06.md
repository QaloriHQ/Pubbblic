# [PUB-08.06] Create customer delivery report and proof bundle

## Objective
Generate per-destination report with URL, submission receipt, status, evidence type and caveats.

## Acceptance criteria
- [ ] Report counts only verified URLs under verified placements.
- [ ] Unknown or pending destinations remain visible with explanation.
- [ ] PDF/CSV exports exclude cross-tenant data and unapproved secrets.

## Dependencies (blocked by)
- PUB-08.03
- PUB-08.04

## Execution metadata
- Epic: PUB-08
- Work wave: W5
- Release gate: G4
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
