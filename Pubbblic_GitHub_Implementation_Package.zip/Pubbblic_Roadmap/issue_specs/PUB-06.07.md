# [PUB-06.07] Create submission activity and event timeline

## Objective
Expose event-by-event execution status, operational evidence and notifications in customer dashboard.

## Acceptance criteria
- [ ] Timeline distinguishes accepted request, submission, review and verified publication.
- [ ] Customers never see internal credential values or unrelated tenant logs.
- [ ] Support can view same timeline with privileged diagnostics.

## Dependencies (blocked by)
- PUB-06.01
- PUB-02.04

## Execution metadata
- Epic: PUB-06
- Work wave: W4
- Release gate: G4
- Priority: P1
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
