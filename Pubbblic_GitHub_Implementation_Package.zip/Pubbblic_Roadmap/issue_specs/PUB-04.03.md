# [PUB-04.03] Add automated content integrity checks

## Objective
Check placeholder text, unsafe links, duplicate stories, PII exposure and policy flags for human follow-up.

## Acceptance criteria
- [ ] Checks produce reasons, severity and evidence without claiming automated fact verification.
- [ ] Flagged content is held for authorized editorial review.
- [ ] False-positive override requires reason and audit history.

## Dependencies (blocked by)
- PUB-04.02
- PUB-03.05

## Execution metadata
- Epic: PUB-04
- Work wave: W3
- Release gate: G2
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
