# [PUB-00.03] Configure Vercel staging and production isolation

## Objective
Create Vercel projects/targets for public site and app with separate staging and production environments and environment promotion rules.

## Acceptance criteria
- [ ] Staging URLs deploy independently of production.
- [ ] No staging database credentials or public URLs exist in production configuration.
- [ ] Environment protection, deployment history and rollback are documented.

## Dependencies (blocked by)
- PUB-00.02

## Execution metadata
- Epic: PUB-00
- Work wave: W1
- Release gate: G1
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
