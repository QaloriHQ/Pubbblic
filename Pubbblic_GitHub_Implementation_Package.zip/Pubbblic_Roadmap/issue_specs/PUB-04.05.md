# [PUB-04.05] Build approved release publishing and corrections

## Objective
Publish approved releases to Pubbblic newsroom and support revisions, corrections, withdrawals and public history notices.

## Acceptance criteria
- [ ] Corrections preserve original version and display date/context.
- [ ] Withdrawn URLs do not continue advertising an active release.
- [ ] Third-party correction obligations generate per-publisher follow-up actions.

## Dependencies (blocked by)
- PUB-04.02
- PUB-03.06

## Execution metadata
- Epic: PUB-04
- Work wave: W3
- Release gate: G2
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
