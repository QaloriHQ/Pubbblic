# [PUB-12.03] Run payments and refund UAT matrix

## Objective
Exercise test checkout, webhooks, refunds, duplicates, disputes, partial delivery and cancel flow.

## Acceptance criteria
- [ ] Ledgers, invoices and delivery entitlements reconcile under replay scenarios.
- [ ] Customer receipts and refund messages match package policy.
- [ ] Live payments remain disabled until authorized business/legal gate.

## Dependencies (blocked by)
- PUB-09.06
- PUB-09.07
- PUB-09.08

## Execution metadata
- Epic: PUB-12
- Work wave: W6
- Release gate: G6
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
