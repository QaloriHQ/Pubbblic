# [PUB-02.03] Implement roles and authorization contracts

## Objective
Implement Owner, Admin, Editor, Approver, Analyst and Billing permissions through server-side policy checks.

## Acceptance criteria
- [ ] Roles are enforced in API handlers and database policies, not only UI.
- [ ] An Editor cannot approve their own release when separation is configured.
- [ ] Permission matrix tests cover both positive and negative cases.

## Dependencies (blocked by)
- PUB-02.02

## Execution metadata
- Epic: PUB-02
- Work wave: W2
- Release gate: G1
- Priority: P0
- Estimate: M (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
