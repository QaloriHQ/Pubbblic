# [PUB-02.02] Create organization and membership model

## Objective
Model customers, agencies, members, invitations, owned brands and organization-level defaults.

## Acceptance criteria
- [ ] Users may belong to more than one organization with explicit active context.
- [ ] Invites expire and cannot grant more privilege than inviter holds.
- [ ] Organization transfer and last-owner safeguards are enforced.

## Dependencies (blocked by)
- PUB-02.01

## Execution metadata
- Epic: PUB-02
- Work wave: W2
- Release gate: G1
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
