# [PUB-02.05] Build agency client and brand workspaces

## Objective
Allow agency members to manage distinct client brands, shared assets, permissions and reporting contexts.

## Acceptance criteria
- [ ] Brand ownership and agency agency-client associations are explicit.
- [ ] Client-facing exports contain only authorized brand data.
- [ ] Switching clients does not leak cached resources or recent search results.

## Dependencies (blocked by)
- PUB-02.04

## Execution metadata
- Epic: PUB-02
- Work wave: W2
- Release gate: G1
- Priority: P1
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
