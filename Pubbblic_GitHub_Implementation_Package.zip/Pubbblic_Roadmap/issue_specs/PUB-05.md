# [PUB-05] Publisher network, permission and commercial contracts

## Outcome
Audit the 19 candidate publishers, define authorized account use, and expose eligibility to the distribution planner.
## Release gate
G3
## Child issues (implementation contracts)
- [ ] PUB-05.01: Build publisher compliance and outreach audit
- [ ] PUB-05.02: Define hybrid account authorization contract
- [ ] PUB-05.03: Create publisher registry, capabilities and pricing
- [ ] PUB-05.04: Design permissions and connection onboarding
- [ ] PUB-05.05: Build publisher network directory and selection UI
- [ ] PUB-05.06: Implement publisher terms/health monitoring
- [ ] PUB-05.07: Establish pilot publisher written authorization
- [ ] PUB-05.08: Add publisher operational scorecard
- [ ] PUB-05.09: Audit publisher: PRLog
- [ ] PUB-05.10: Audit publisher: PR.com
- [ ] PUB-05.11: Audit publisher: NewswireToday
- [ ] PUB-05.12: Audit publisher: 1888PressRelease
- [ ] PUB-05.13: Audit publisher: OpenPR
- [ ] PUB-05.14: Audit publisher: PR-Inside
- [ ] PUB-05.15: Audit publisher: Online PR News
- [ ] PUB-05.16: Audit publisher: PRFire
- [ ] PUB-05.17: Audit publisher: PRZoom
- [ ] PUB-05.18: Audit publisher: PRWirePro
- [ ] PUB-05.19: Audit publisher: PRUrgent
- [ ] PUB-05.20: Audit publisher: Express Press Release Distribution
- [ ] PUB-05.21: Audit publisher: PRFree
- [ ] PUB-05.22: Audit publisher: PRWire Australia
- [ ] PUB-05.23: Audit publisher: PRWire India
- [ ] PUB-05.24: Audit publisher: Free Press Release Center
- [ ] PUB-05.25: Audit publisher: Press Release Power
- [ ] PUB-05.26: Audit publisher: PRSync
- [ ] PUB-05.27: Audit publisher: PRBD
- [ ] PUB-05.28: Consolidate candidate publisher audit and MVP shortlist

## Epic completion conditions
- [ ] All P0 children passed acceptance and merged to staging
- [ ] Evidence and security/privacy review recorded in child issues
- [ ] Relevant release gate explicitly approved; production changes not implied
- [ ] Risks, follow-on tasks and known limitations documented

**Ownership:** Product approval is required for scope changes and every production authorization.
