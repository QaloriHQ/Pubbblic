# [PUB-00.05] Establish CI and branch protection

## Objective
Build lint, typecheck, unit, integration, dependency and secret scanning CI with staging PR requirements and protected production branches.

## Acceptance criteria
- [ ] Pull requests cannot merge while required checks fail.
- [ ] Secrets and high-severity vulnerabilities block release per documented policy.
- [ ] Release artifacts and test evidence are retained with commits.

## Dependencies (blocked by)
- PUB-00.02

## Execution metadata
- Epic: PUB-00
- Work wave: W1
- Release gate: G1
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
