# [PUB-04.01] Define editorial policies and prohibited content

## Objective
Publish the policy for factual assertions, impersonation, disclosures, financial claims, misleading endorsements and spam.

## Acceptance criteria
- [ ] Policy covers impersonation, fabricated news, deceptive investment promotion and unauthorized copyrighted material.
- [ ] Guidelines distinguish paid distribution, editorial coverage and hosted posting.
- [ ] A reviewer can cite a specific policy rationale for every rejection.

## Dependencies (blocked by)
- PUB-00.01

## Execution metadata
- Epic: PUB-04
- Work wave: W3
- Release gate: G2
- Priority: P0
- Estimate: M (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
