# [PUB-06.01] Define campaign and destination state machines

## Objective
Specify campaign, destination, attempt and verification states with terminal and retryable outcomes.

## Acceptance criteria
- [ ] State chart includes assistance, editorial pending, ambiguous result and withdrawn conditions.
- [ ] Invalid transitions are rejected both in code and database access paths.
- [ ] Events retain actor, timestamps, version and correlation IDs.

## Dependencies (blocked by)
- PUB-00.01
- PUB-05.03

## Execution metadata
- Epic: PUB-06
- Work wave: W4
- Release gate: G4
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
