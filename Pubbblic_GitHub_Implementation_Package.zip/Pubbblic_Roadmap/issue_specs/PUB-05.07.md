# [PUB-05.07] Establish pilot publisher written authorization

## Objective
Obtain explicit API access, browser automation permission or managed distribution agreement for at least one pilot destination.

## Acceptance criteria
- [ ] Written scope covers actor, account, submission method, rate, geography and test environment.
- [ ] Evidence is attached to the publisher registry and approved by a designated reviewer.
- [ ] No production submission goes live before the authorization record passes review.

## Dependencies (blocked by)
- PUB-05.01
- PUB-05.02

## Execution metadata
- Epic: PUB-05
- Work wave: W3
- Release gate: G3
- Priority: P0
- Estimate: M (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
