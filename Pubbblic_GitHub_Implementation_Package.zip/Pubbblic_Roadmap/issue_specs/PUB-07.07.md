# [PUB-07.07] Implement connector selector/version drift alerts

## Objective
Track DOM/API contract changes and require review of new selectors or partner API versions before promotion.

## Acceptance criteria
- [ ] Broken selectors disable affected connector automatically after threshold.
- [ ] No unreviewed selector changes auto-publish to production.
- [ ] Versioned test artifacts record supported publisher layout.

## Dependencies (blocked by)
- PUB-07.04
- PUB-07.05

## Execution metadata
- Epic: PUB-07
- Work wave: W4
- Release gate: G4
- Priority: P1
- Estimate: M (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
