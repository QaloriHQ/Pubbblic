# [PUB-07.04] Implement approved browser connector pilot

## Objective
Implement a single permitted publisher automation with selectors, field mapping, uploads, observable manual checks and submission receipt.

## Acceptance criteria
- [ ] Written permission for this exact workflow is linked in the connector record.
- [ ] Submission exits for CAPTCHA/MFA or ToS conflicts without evasion.
- [ ] Pilot fixture passes staging tests for success and failure outcomes.

## Dependencies (blocked by)
- PUB-05.07
- PUB-07.01
- PUB-07.02
- PUB-07.03

## Execution metadata
- Epic: PUB-07
- Work wave: W4
- Release gate: G4
- Priority: P0
- Estimate: L (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
