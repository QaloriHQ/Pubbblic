# [PUB-05.05] Build publisher network directory and selection UI

## Objective
Create searchable, filterable publisher cards and destination selection with price and eligibility disclosures.

## Acceptance criteria
- [ ] Customers can filter by geographic reach, subject, workflow, costs and availability.
- [ ] Selections that are unavailable or unauthorized are disabled with clear reasons.
- [ ] Selection snapshot preserves displayed entitlements at checkout.

## Dependencies (blocked by)
- PUB-05.03
- PUB-00.06

## Execution metadata
- Epic: PUB-05
- Work wave: W3
- Release gate: G3
- Priority: P1
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
