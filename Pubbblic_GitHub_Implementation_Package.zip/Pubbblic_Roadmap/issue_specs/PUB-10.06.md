# [PUB-10.06] Build baseline AI visibility measurement experiment

## Objective
Define opt-in prompt sets, search citations, response snapshots and confidence labels without promises of AI pickup.

## Acceptance criteria
- [ ] Prompts, engine/model, region and run date are recorded for reproducibility.
- [ ] Reports distinguish observed mention, cited link and inferred reach.
- [ ] Launch copy avoids claiming guaranteed model training or future citation.

## Dependencies (blocked by)
- PUB-10.04

## Execution metadata
- Epic: PUB-10
- Work wave: W5
- Release gate: G7
- Priority: P2
- Estimate: M (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
