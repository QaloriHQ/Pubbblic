# [PUB-03] Press release creation and publishing workflow

## Outcome
Support authoring, immutable approval versions, media handling and publication preparation.
## Release gate
G2
## Child issues (implementation contracts)
- [ ] PUB-03.01: Define release content schema and validation
- [ ] PUB-03.02: Build autosave rich-text release editor
- [ ] PUB-03.03: Create company boilerplates and media contacts
- [ ] PUB-03.04: Build press release template gallery
- [ ] PUB-03.05: Implement media asset pipeline
- [ ] PUB-03.06: Build version history, compare and restore
- [ ] PUB-03.07: Build release previews and shareable proofs
- [ ] PUB-03.08: Implement scheduling and timezone handling

## Epic completion conditions
- [ ] All P0 children passed acceptance and merged to staging
- [ ] Evidence and security/privacy review recorded in child issues
- [ ] Relevant release gate explicitly approved; production changes not implied
- [ ] Risks, follow-on tasks and known limitations documented

**Ownership:** Product approval is required for scope changes and every production authorization.
