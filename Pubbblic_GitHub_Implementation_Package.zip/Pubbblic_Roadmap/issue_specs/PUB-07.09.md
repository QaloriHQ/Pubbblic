# [PUB-07.09] Run authorized end-to-end publisher pilot

## Objective
Execute controlled staging and limited-live cases with explicit client/test authorization and verify final evidence.

## Acceptance criteria
- [ ] At least 20 controlled scenarios cover success, refusal, editorial pending, ambiguity and cancellation (simulation allowed where live actions are inappropriate).
- [ ] No unauthorized submissions or duplicate publishes occur in evaluation.
- [ ] Pilot postmortem records success rate, cost, limitations and go/no-go.

## Dependencies (blocked by)
- PUB-07.04
- PUB-07.06
- PUB-07.08
- PUB-08.03

## Execution metadata
- Epic: PUB-07
- Work wave: W5
- Release gate: G4
- Priority: P0
- Estimate: L (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
