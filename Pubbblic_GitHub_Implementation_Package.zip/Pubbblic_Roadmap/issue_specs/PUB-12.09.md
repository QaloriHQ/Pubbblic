# [PUB-12.09] Obtain explicit production launch authorization

## Objective
Present evidence for all gates and request owner decision before enabling production payment and publisher submission paths.

## Acceptance criteria
- [ ] All mandatory G1–G6 evidence links are current and reviewed.
- [ ] No P0 defects, unresolved critical vulnerabilities or missing publisher permissions remain.
- [ ] Production feature flags only enable after recorded explicit owner approval.

## Dependencies (blocked by)
- PUB-12.01
- PUB-12.02
- PUB-12.03
- PUB-12.05
- PUB-12.06
- PUB-12.07
- PUB-12.08

## Execution metadata
- Epic: PUB-12
- Work wave: W6
- Release gate: G6
- Priority: P0
- Estimate: M (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
