# [PUB-06.05] Build publish scheduling and embargo enforcement

## Objective
Implement timezone-safe due-time handling, account-specific windows, pause/resume and cancellation semantics.

## Acceptance criteria
- [ ] Embargoes and scheduled releases are never dispatched early.
- [ ] Cancellation affects not-yet-sent jobs and reports publisher-side limitations accurately.
- [ ] Daylight saving and delayed worker cases have automated tests.

## Dependencies (blocked by)
- PUB-03.08
- PUB-06.02

## Execution metadata
- Epic: PUB-06
- Work wave: W4
- Release gate: G4
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
