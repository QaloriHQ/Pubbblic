# [PUB-05.01] Build publisher compliance and outreach audit

## Objective
Audit 19 candidates for submission method, ToS, explicit automation permissions, redistribution rights, costs, review time and geography.

## Acceptance criteria
- [ ] Each site has dated evidence and one of API, browser-authorized, assisted, partner or unsupported.
- [ ] No automatic submissions are enabled without documented permission.
- [ ] Contacts and outstanding authorization questions are assigned owners.

## Dependencies (blocked by)
- PUB-00.01

## Execution metadata
- Epic: PUB-05
- Work wave: W3
- Release gate: G3
- Priority: P0
- Estimate: L (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
