# [PUB-05.11] Audit publisher: NewswireToday

## Objective
Due-diligence review of https://www.newswiretoday.com/ before enabling Pubbblic distribution. This is a candidate, not an integration approval.

## Acceptance criteria
- [ ] Record dated evidence of current NewswireToday signup/submission path, published terms, editorial process and whether submissions from third-party services are allowed.
- [ ] Capture account ownership, API availability, paid/free fees, geographical/media/category limits, MFA/CAPTCHA/manual constraints and receipt verification.
- [ ] Save reviewer, source links, last-reviewed date and written automation authorization where obtained; mark unsupported or manual-only otherwise.

## Dependencies (blocked by)
- PUB-05.01

## Execution metadata
- Epic: PUB-05
- Work wave: W3
- Release gate: G3
- Priority: P0
- Estimate: S (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
