# [PUB-03.01] Define release content schema and validation

## Objective
Specify fields for headline, summary, dateline, issuer, body, quotes, boilerplate, source, media contacts and assets.

## Acceptance criteria
- [ ] Schema validates mandatory fields, length ranges and link/media limits.
- [ ] Publisher-specific requirements extend but never overwrite the canonical release.
- [ ] Sanitization preserves supported formatting without executable HTML.

## Dependencies (blocked by)
- PUB-00.04
- PUB-02.04

## Execution metadata
- Epic: PUB-03
- Work wave: W3
- Release gate: G2
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
