# [PUB-01] Brand, marketing and public newsroom

## Outcome
Launch a distinctive Pubbblic marketing experience informed by EZ Newswire interaction patterns, without copying its branding.
## Release gate
G2
## Child issues (implementation contracts)
- [ ] PUB-01.01: Build original brand and marketing information architecture
- [ ] PUB-01.02: Implement conversion-focused marketing pages
- [ ] PUB-01.03: Publish accurate network and pricing pages
- [ ] PUB-01.04: Launch publicly searchable newsroom
- [ ] PUB-01.05: Implement technical SEO and structured content
- [ ] PUB-01.06: Create content guidelines, privacy and submission terms
- [ ] PUB-01.07: Instrument marketing-to-app attribution

## Epic completion conditions
- [ ] All P0 children passed acceptance and merged to staging
- [ ] Evidence and security/privacy review recorded in child issues
- [ ] Relevant release gate explicitly approved; production changes not implied
- [ ] Risks, follow-on tasks and known limitations documented

**Ownership:** Product approval is required for scope changes and every production authorization.
