# [PUB-09.02] Integrate Stripe customer and checkout flows

## Objective
Create products/prices, checkout, customer portal and invoice/receipt references with least-privilege keys.

## Acceptance criteria
- [ ] No card data is stored directly by Pubbblic.
- [ ] Staging/test and production/live Stripe resources are separate.
- [ ] Abandoned, failed and completed checkout paths are user-tested.

## Dependencies (blocked by)
- PUB-09.01
- PUB-02.04

## Execution metadata
- Epic: PUB-09
- Work wave: W5
- Release gate: G5
- Priority: P0
- Estimate: L (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
