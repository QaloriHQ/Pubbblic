# [PUB-10.08] Build campaign performance and service SLO exports

## Objective
Track queue time, processing duration, connector reliability, verified placement rate and customer-side completion metrics.

## Acceptance criteria
- [ ] Operational metrics are sliced by publisher mode and connector version.
- [ ] SLOs include numerator/denominator and reporting interval.
- [ ] Alerts identify regressions without leaking customer release text.

## Dependencies (blocked by)
- PUB-10.03
- PUB-00.07

## Execution metadata
- Epic: PUB-10
- Work wave: W5
- Release gate: G5
- Priority: P1
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
