# [PUB-08.03] Implement verification service and publication matching

## Objective
Check accessible live URLs and match release identity/content against approved version using defensible checks.

## Acceptance criteria
- [ ] Publication cannot be marked verified solely from a success toast.
- [ ] Verifier handles delays, paywalls, canonical redirects and unavailable sites without false positives.
- [ ] Evidence includes match rationale and last checked timestamp.

## Dependencies (blocked by)
- PUB-08.01
- PUB-08.02

## Execution metadata
- Epic: PUB-08
- Work wave: W5
- Release gate: G4
- Priority: P0
- Estimate: L (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
