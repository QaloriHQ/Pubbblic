# [PUB-12] Quality, UAT and production authorization

## Outcome
Enforce evidence-based MVP acceptance and safe launch practices.
## Release gate
G6
## Child issues (implementation contracts)
- [ ] PUB-12.01: Build end-to-end happy-path acceptance test
- [ ] PUB-12.02: Run tenant isolation and auth penetration review
- [ ] PUB-12.03: Run payments and refund UAT matrix
- [ ] PUB-12.04: Run resilience, load and worker crash exercises
- [ ] PUB-12.05: Verify backups, restore and disaster recovery
- [ ] PUB-12.06: Complete legal and publisher authorization signoff
- [ ] PUB-12.07: Complete accessibility and mobile QA
- [ ] PUB-12.08: Prepare launch monitoring, rollback and support
- [ ] PUB-12.09: Obtain explicit production launch authorization

## Epic completion conditions
- [ ] All P0 children passed acceptance and merged to staging
- [ ] Evidence and security/privacy review recorded in child issues
- [ ] Relevant release gate explicitly approved; production changes not implied
- [ ] Risks, follow-on tasks and known limitations documented

**Ownership:** Product approval is required for scope changes and every production authorization.
