# [PUB-11.01] Build restricted admin control plane

## Objective
Provide operator access to organizations, releases, campaigns, publisher health and moderation with explicit privileged role.

## Acceptance criteria
- [ ] Customer users cannot access operator routes or underlying queries.
- [ ] All admin actions have actor, reason and before/after audit event.
- [ ] Support read-only is default; high-risk writes require elevated permission.

## Dependencies (blocked by)
- PUB-02.04
- PUB-06.07

## Execution metadata
- Epic: PUB-11
- Work wave: W6
- Release gate: G6
- Priority: P0
- Estimate: M (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
