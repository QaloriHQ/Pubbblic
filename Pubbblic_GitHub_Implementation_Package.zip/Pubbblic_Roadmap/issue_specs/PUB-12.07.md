# [PUB-12.07] Complete accessibility and mobile QA

## Objective
Audit core signup, editor, campaign tracker, checkout and reporting across supported devices and keyboard/screen readers.

## Acceptance criteria
- [ ] No blocking WCAG 2.2 AA issues remain in core transaction paths.
- [ ] Error/loading and reduced-motion behavior is predictable.
- [ ] Documented browser/device matrix receives acceptance evidence.

## Dependencies (blocked by)
- PUB-01.02
- PUB-03.02
- PUB-10.03

## Execution metadata
- Epic: PUB-12
- Work wave: W6
- Release gate: G6
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
