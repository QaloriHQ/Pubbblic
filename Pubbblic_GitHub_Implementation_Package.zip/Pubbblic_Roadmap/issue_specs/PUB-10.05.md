# [PUB-10.05] Build downloadable reports and agency branding

## Objective
Create exportable campaign reports with dated evidence, client branding, share permissions and summary narratives.

## Acceptance criteria
- [ ] Reports identify verified placements and unresolved destinations accurately.
- [ ] Export access follows organization and brand permissions.
- [ ] Report generation has snapshot IDs and excludes stale private links.

## Dependencies (blocked by)
- PUB-08.06
- PUB-02.05

## Execution metadata
- Epic: PUB-10
- Work wave: W5
- Release gate: G5
- Priority: P1
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
