# [PUB-03.08] Implement scheduling and timezone handling

## Objective
Let authorized users request publish windows with explicit timezone, expiry and embargo semantics.

## Acceptance criteria
- [ ] UTC storage and local display roundtrip across daylight-saving transitions.
- [ ] Users cannot schedule in the past or bypass editor approval.
- [ ] Embargoed content is not submitted to destinations before eligibility allows.

## Dependencies (blocked by)
- PUB-03.06
- PUB-04.02

## Execution metadata
- Epic: PUB-03
- Work wave: W3
- Release gate: G2
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
