# [PUB-03.03] Create company boilerplates and media contacts

## Objective
Support reusable issuer profiles, addresses, logo variants, press contacts, and verified organization data.

## Acceptance criteria
- [ ] Users can select a brand profile and override permitted release fields.
- [ ] Sensitive contacts have disclosure options and consent boundaries.
- [ ] Published snapshot remains stable after a profile changes.

## Dependencies (blocked by)
- PUB-02.05
- PUB-03.01

## Execution metadata
- Epic: PUB-03
- Work wave: W3
- Release gate: G2
- Priority: P1
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
