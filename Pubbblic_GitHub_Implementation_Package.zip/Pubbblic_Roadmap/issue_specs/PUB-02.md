# [PUB-02] Identity, organizations and secure access

## Outcome
Support self-serve users and agency teams with strict tenant isolation and authorization.
## Release gate
G1
## Child issues (implementation contracts)
- [ ] PUB-02.01: Implement Supabase Auth and account onboarding
- [ ] PUB-02.02: Create organization and membership model
- [ ] PUB-02.03: Implement roles and authorization contracts
- [ ] PUB-02.04: Apply tenant RLS across all product data
- [ ] PUB-02.05: Build agency client and brand workspaces
- [ ] PUB-02.06: Add account settings, security sessions and notifications
- [ ] PUB-02.07: Implement organization-level approval configuration
- [ ] PUB-02.08: Design multi-tenant account export and deletion

## Epic completion conditions
- [ ] All P0 children passed acceptance and merged to staging
- [ ] Evidence and security/privacy review recorded in child issues
- [ ] Relevant release gate explicitly approved; production changes not implied
- [ ] Risks, follow-on tasks and known limitations documented

**Ownership:** Product approval is required for scope changes and every production authorization.
