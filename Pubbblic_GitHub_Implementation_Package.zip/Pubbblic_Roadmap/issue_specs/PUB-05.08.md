# [PUB-05.08] Add publisher operational scorecard

## Objective
Record acceptance, latency, verified placement, support incidents, cost and contractual constraints per destination.

## Acceptance criteria
- [ ] Scorecard separates known historical facts from unavailable statistics.
- [ ] Low-quality or non-compliant publishers can be hidden from selection.
- [ ] Daily metrics identify pilot candidates and risk concentrations.

## Dependencies (blocked by)
- PUB-05.03
- PUB-08.03

## Execution metadata
- Epic: PUB-05
- Work wave: W5
- Release gate: G3
- Priority: P1
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
