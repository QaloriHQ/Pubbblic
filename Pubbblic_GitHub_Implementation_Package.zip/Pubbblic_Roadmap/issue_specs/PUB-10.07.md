# [PUB-10.07] Create Mixpanel launch dashboards and cohort analysis

## Objective
Set up acquisition-to-first-release funnel, publish-success segments, activation, repeat release and retention cohorts.

## Acceptance criteria
- [ ] Core dashboards are validated against deterministic sample user journeys.
- [ ] A weekly KPI review owner and definitions are documented.
- [ ] Server and client duplicate events are guarded.

## Dependencies (blocked by)
- PUB-10.02
- PUB-09.03

## Execution metadata
- Epic: PUB-10
- Work wave: W5
- Release gate: G5
- Priority: P1
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
