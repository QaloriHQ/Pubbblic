# [PUB-10.03] Create customer campaign overview dashboard

## Objective
Build campaign cards, status filters, KPI totals, destinations and activity views scoped by organization.

## Acceptance criteria
- [ ] Metrics count selected, submitted, editorial pending and published separately.
- [ ] All date filters and status totals reconcile to source-of-truth database.
- [ ] Large organization datasets render within performance budget.

## Dependencies (blocked by)
- PUB-06.07
- PUB-08.03

## Execution metadata
- Epic: PUB-10
- Work wave: W5
- Release gate: G5
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
