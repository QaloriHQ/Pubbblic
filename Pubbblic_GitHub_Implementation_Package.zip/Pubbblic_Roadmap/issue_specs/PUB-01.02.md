# [PUB-01.02] Implement conversion-focused marketing pages

## Objective
Build responsive home, how-it-works, solutions and features pages with product tour blocks and clear conversion paths.

## Acceptance criteria
- [ ] All public CTAs route to actual signup or contact flows.
- [ ] Core pages pass mobile, keyboard and basic performance QA.
- [ ] No fictional proof points, publisher logos or ratings are displayed.

## Dependencies (blocked by)
- PUB-01.01
- PUB-00.03

## Execution metadata
- Epic: PUB-01
- Work wave: W2
- Release gate: G2
- Priority: P1
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
