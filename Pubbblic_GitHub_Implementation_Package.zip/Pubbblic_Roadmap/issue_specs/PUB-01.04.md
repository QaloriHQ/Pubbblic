# [PUB-01.04] Launch publicly searchable newsroom

## Objective
Publish approved Pubbblic-hosted releases with unique URLs, issuer identity, media assets, category browsing and search.

## Acceptance criteria
- [ ] Only approved released content is publicly served.
- [ ] Unpublished and withdrawn content follows clear HTTP/indexing rules.
- [ ] Canonical URLs and search metadata are deterministic.

## Dependencies (blocked by)
- PUB-03.07
- PUB-04.05

## Execution metadata
- Epic: PUB-01
- Work wave: W3
- Release gate: G2
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
