# [PUB-04.06] Build moderation case management

## Objective
Create abuse reports, reviewer assignments, escalation paths, evidence retention and appeals handling.

## Acceptance criteria
- [ ] Cases have owner, SLA, immutable actions and reason codes.
- [ ] Urgent fraud/impersonation cases can pause related campaigns.
- [ ] Customer notices avoid revealing sensitive third-party report data.

## Dependencies (blocked by)
- PUB-04.03
- PUB-04.04

## Execution metadata
- Epic: PUB-04
- Work wave: W3
- Release gate: G2
- Priority: P1
- Estimate: M (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
