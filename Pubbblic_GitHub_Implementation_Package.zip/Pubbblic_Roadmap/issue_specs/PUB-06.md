# [PUB-06] Distribution orchestration and scheduling

## Outcome
Implement reliable, idempotent job routing independent of browser or API implementation.
## Release gate
G4
## Child issues (implementation contracts)
- [ ] PUB-06.01: Define campaign and destination state machines
- [ ] PUB-06.02: Implement durable queue and task leasing
- [ ] PUB-06.03: Build eligibility routing and execution plans
- [ ] PUB-06.04: Implement submission idempotency and reconciliation
- [ ] PUB-06.05: Build publish scheduling and embargo enforcement
- [ ] PUB-06.06: Add publisher concurrency and rate controls
- [ ] PUB-06.07: Create submission activity and event timeline
- [ ] PUB-06.08: Implement retry budgets and human escalation
- [ ] PUB-06.09: Build distribution integration test harness

## Epic completion conditions
- [ ] All P0 children passed acceptance and merged to staging
- [ ] Evidence and security/privacy review recorded in child issues
- [ ] Relevant release gate explicitly approved; production changes not implied
- [ ] Risks, follow-on tasks and known limitations documented

**Ownership:** Product approval is required for scope changes and every production authorization.
