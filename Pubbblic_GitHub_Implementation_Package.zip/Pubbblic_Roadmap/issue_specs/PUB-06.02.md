# [PUB-06.02] Implement durable queue and task leasing

## Objective
Configure pgmq-backed submission queues, dead-letter strategy, visibility timeout and fair scheduling.

## Acceptance criteria
- [ ] Worker crashes recover tasks without losing or indefinitely locking jobs.
- [ ] Expired leases can be reconciled safely and are not blindly resubmitted.
- [ ] Backlog depth, retries and DLQ alerts are exposed to operators.

## Dependencies (blocked by)
- PUB-00.04
- PUB-00.07
- PUB-06.01

## Execution metadata
- Epic: PUB-06
- Work wave: W4
- Release gate: G4
- Priority: P0
- Estimate: L (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
