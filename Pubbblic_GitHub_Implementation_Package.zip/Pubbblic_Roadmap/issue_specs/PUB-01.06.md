# [PUB-01.06] Create content guidelines, privacy and submission terms

## Objective
Draft legal-facing public pages explaining editorial policy, content ownership, distribution limits and data processing.

## Acceptance criteria
- [ ] Terms specify publisher review and non-guaranteed placement.
- [ ] Consent, privacy, corrections, and removal requests have contact paths.
- [ ] Legal review is required before production launch.

## Dependencies (blocked by)
- PUB-04.01
- PUB-05.01

## Execution metadata
- Epic: PUB-01
- Work wave: W3
- Release gate: G2
- Priority: P0
- Estimate: M (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
