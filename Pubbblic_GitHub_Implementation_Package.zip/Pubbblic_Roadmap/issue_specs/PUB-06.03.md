# [PUB-06.03] Build eligibility routing and execution plans

## Objective
Resolve selected publishers, account ownership, permitted mode, caps, lead times and payment status into a dispatch plan.

## Acceptance criteria
- [ ] Ineligible publishers never enter executable queue.
- [ ] Customer sees which destinations are automated, assisted or managed.
- [ ] Any change after approval requires revised plan and authorization check.

## Dependencies (blocked by)
- PUB-05.03
- PUB-05.04
- PUB-06.01

## Execution metadata
- Epic: PUB-06
- Work wave: W4
- Release gate: G4
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
