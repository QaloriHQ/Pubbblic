# [PUB-10] Customer reporting, Mixpanel and AI visibility

## Outcome
Deliver evidence-grounded customer and product analytics with appropriate metric provenance.
## Release gate
G5
## Child issues (implementation contracts)
- [ ] PUB-10.01: Define event taxonomy and consent policy
- [ ] PUB-10.02: Instrument critical release conversion funnel
- [ ] PUB-10.03: Create customer campaign overview dashboard
- [ ] PUB-10.04: Implement publisher/source metric provenance
- [ ] PUB-10.05: Build downloadable reports and agency branding
- [ ] PUB-10.06: Build baseline AI visibility measurement experiment
- [ ] PUB-10.07: Create Mixpanel launch dashboards and cohort analysis
- [ ] PUB-10.08: Build campaign performance and service SLO exports

## Epic completion conditions
- [ ] All P0 children passed acceptance and merged to staging
- [ ] Evidence and security/privacy review recorded in child issues
- [ ] Relevant release gate explicitly approved; production changes not implied
- [ ] Risks, follow-on tasks and known limitations documented

**Ownership:** Product approval is required for scope changes and every production authorization.
