# [PUB-05.03] Create publisher registry, capabilities and pricing

## Objective
Implement publisher profile, submission restrictions, network geography, media support, fees, acceptance rate and effective-date versioning.

## Acceptance criteria
- [ ] Unknown or stale capabilities are displayed as unverified rather than available.
- [ ] Price changes have effective time and audit history.
- [ ] Eligibility is evaluated server-side before selection and dispatch.

## Dependencies (blocked by)
- PUB-05.01
- PUB-00.04

## Execution metadata
- Epic: PUB-05
- Work wave: W3
- Release gate: G3
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
