# [PUB-04.02] Build editorial state machine and approval queue

## Objective
Implement draft, ready-for-review, changes-requested, approved, scheduled, rejected and withdrawn transitions.

## Acceptance criteria
- [ ] All transitions enforce role permissions and required signoffs.
- [ ] Users receive actionable comments with revision requests.
- [ ] No campaign can dispatch without the exact approved version.

## Dependencies (blocked by)
- PUB-03.01
- PUB-04.01

## Execution metadata
- Epic: PUB-04
- Work wave: W3
- Release gate: G2
- Priority: P0
- Estimate: L (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
