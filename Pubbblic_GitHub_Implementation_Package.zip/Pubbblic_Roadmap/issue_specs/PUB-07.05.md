# [PUB-07.05] Implement API/partner connector reference

## Objective
Create an API-first connector with scoped credentials, request signing if needed, idempotency support and response handling.

## Acceptance criteria
- [ ] Conforms to same adapter contract and normalized states as browser mode.
- [ ] Errors distinguish provider rejection, transient failure and uncertain outcome.
- [ ] Contract tests cover authorization, rate limit and response replay.

## Dependencies (blocked by)
- PUB-07.01
- PUB-07.03

## Execution metadata
- Epic: PUB-07
- Work wave: W4
- Release gate: G4
- Priority: P1
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
