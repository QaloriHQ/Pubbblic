# [PUB-00.07] Implement observability and error taxonomy

## Objective
Introduce structured JSON logs, correlation IDs, sanitized error codes and traces across API, queue and browser worker.

## Acceptance criteria
- [ ] A campaign ID traces the complete lifecycle without disclosing secrets.
- [ ] Every failure has an actionable code and owner escalation category.
- [ ] Dashboards and alert thresholds cover job failure, latency and backlog.

## Dependencies (blocked by)
- PUB-00.02
- PUB-00.04

## Execution metadata
- Epic: PUB-00
- Work wave: W1
- Release gate: G1
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
