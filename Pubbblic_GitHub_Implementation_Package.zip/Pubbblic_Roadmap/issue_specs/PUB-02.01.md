# [PUB-02.01] Implement Supabase Auth and account onboarding

## Objective
Build email-based signup, verified email flow, login, reset and session management with rate limits and clear errors.

## Acceptance criteria
- [ ] Unauthenticated visitors may browse marketing and public releases but cannot distribute.
- [ ] Auth redirects are restricted to allowed staging/production origins.
- [ ] Recovery, invalid link and expired session flows pass tests.

## Dependencies (blocked by)
- PUB-00.04
- PUB-00.06

## Execution metadata
- Epic: PUB-02
- Work wave: W2
- Release gate: G1
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
