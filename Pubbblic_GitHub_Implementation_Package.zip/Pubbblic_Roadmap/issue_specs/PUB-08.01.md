# [PUB-08.01] Define placement evidence model and trust levels

## Objective
Model submission receipt, publisher editorial acceptance, visible live URL, content match, timestamp, and verification source.

## Acceptance criteria
- [ ] Evidence taxonomy explicitly distinguishes submitted, accepted and published.
- [ ] Each signal includes timestamp, origin and reliability level.
- [ ] Manual override is attributed and cannot silently fabricate a verified placement.

## Dependencies (blocked by)
- PUB-06.01
- PUB-07.01

## Execution metadata
- Epic: PUB-08
- Work wave: W5
- Release gate: G4
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
