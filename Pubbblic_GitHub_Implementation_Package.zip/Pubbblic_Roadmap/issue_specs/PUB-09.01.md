# [PUB-09.01] Define package catalog and unit economics

## Objective
Specify hosted-only, managed, connected-account and assisted packages with transparent inclusion/exclusion rules.

## Acceptance criteria
- [ ] Pricing accounts for verified destination fees, editorial labor and worker costs.
- [ ] No package claims guaranteed editorial placement without contractual basis.
- [ ] Versioned package snapshots are persisted at purchase.

## Dependencies (blocked by)
- PUB-05.03
- PUB-00.01

## Execution metadata
- Epic: PUB-09
- Work wave: W5
- Release gate: G5
- Priority: P0
- Estimate: M (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
