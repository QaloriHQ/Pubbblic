# [PUB-12.04] Run resilience, load and worker crash exercises

## Objective
Stress API, queue and browser workloads, simulate worker loss, vendor timeout, DLQ recovery and burst scheduling.

## Acceptance criteria
- [ ] Load targets and SLOs are documented and demonstrated.
- [ ] No duplicate publishing occurs after crash/lease recovery.
- [ ] Operations runbook identifies recovery and escalation steps.

## Dependencies (blocked by)
- PUB-06.09
- PUB-07.09
- PUB-11.02

## Execution metadata
- Epic: PUB-12
- Work wave: W6
- Release gate: G6
- Priority: P0
- Estimate: L (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
