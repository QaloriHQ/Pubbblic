# [PUB-07.02] Provision isolated Puppeteer worker runtime

## Objective
Build containerized Chrome worker separate from Vercel with process limits, per-job contexts and safe teardown.

## Acceptance criteria
- [ ] Each job uses isolated browser context and cleared state.
- [ ] Timeout, memory, filesystem and network egress limits are enforced.
- [ ] Health checks and worker restarts do not lose queue events.

## Dependencies (blocked by)
- PUB-00.08
- PUB-06.02

## Execution metadata
- Epic: PUB-07
- Work wave: W4
- Release gate: G4
- Priority: P0
- Estimate: L (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
