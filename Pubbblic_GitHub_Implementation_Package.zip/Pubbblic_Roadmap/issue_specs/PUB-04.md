# [PUB-04] Editorial integrity, claims and approval

## Outcome
Prevent low-quality, deceptive or unauthorized releases from entering the distribution network.
## Release gate
G2
## Child issues (implementation contracts)
- [ ] PUB-04.01: Define editorial policies and prohibited content
- [ ] PUB-04.02: Build editorial state machine and approval queue
- [ ] PUB-04.03: Add automated content integrity checks
- [ ] PUB-04.04: Implement issuer identity and authorization review
- [ ] PUB-04.05: Build approved release publishing and corrections
- [ ] PUB-04.06: Build moderation case management
- [ ] PUB-04.07: Create editorial quality UAT suite

## Epic completion conditions
- [ ] All P0 children passed acceptance and merged to staging
- [ ] Evidence and security/privacy review recorded in child issues
- [ ] Relevant release gate explicitly approved; production changes not implied
- [ ] Risks, follow-on tasks and known limitations documented

**Ownership:** Product approval is required for scope changes and every production authorization.
