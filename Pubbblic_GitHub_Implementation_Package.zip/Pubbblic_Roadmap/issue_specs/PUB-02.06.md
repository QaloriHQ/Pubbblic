# [PUB-02.06] Add account settings, security sessions and notifications

## Objective
Deliver profile settings, session management, notification preferences and notification delivery infrastructure.

## Acceptance criteria
- [ ] Users can revoke other sessions and review active account context.
- [ ] Transactional notifications respect mandatory versus optional delivery classes.
- [ ] Security-relevant changes are audited.

## Dependencies (blocked by)
- PUB-02.04

## Execution metadata
- Epic: PUB-02
- Work wave: W2
- Release gate: G1
- Priority: P1
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
