# [PUB-11.02] Create connector kill switches and incident controls

## Objective
Allow disabling publisher, connection, worker group or campaign queue without deploying code.

## Acceptance criteria
- [ ] Kill switch takes effect before next task lease.
- [ ] Customer-visible status explains paused services without exposing internal details.
- [ ] Re-enable requires owner authorization for prohibited or permission-related incidents.

## Dependencies (blocked by)
- PUB-05.06
- PUB-06.06

## Execution metadata
- Epic: PUB-11
- Work wave: W6
- Release gate: G6
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
