# [PUB-12.01] Build end-to-end happy-path acceptance test

## Objective
Test signup, organization, draft, approval, publisher choice, payment, distribution, verified publication and reporting.

## Acceptance criteria
- [ ] One complete sandbox-to-authorized-destination scenario passes with recorded evidence.
- [ ] Staging and production configuration differences are checked.
- [ ] Tests assert no state is skipped or reported optimistically.

## Dependencies (blocked by)
- PUB-02.04
- PUB-04.07
- PUB-07.09
- PUB-09.04
- PUB-10.03

## Execution metadata
- Epic: PUB-12
- Work wave: W6
- Release gate: G6
- Priority: P0
- Estimate: L (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
