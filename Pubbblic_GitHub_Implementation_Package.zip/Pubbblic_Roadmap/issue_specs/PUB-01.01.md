# [PUB-01.01] Build original brand and marketing information architecture

## Objective
Specify brand tokens, messaging, navigation, CTAs, legal links, mobile layouts, and original positioning for Pubbblic.

## Acceptance criteria
- [ ] Information architecture covers Platform, Network, Solutions, Pricing, Newsroom, Resources and Legal.
- [ ] Marketing claims never imply publisher partnerships that have not been established.
- [ ] Brand and copy are independently authored rather than reproduced from the reference.

## Dependencies (blocked by)
- PUB-00.06

## Execution metadata
- Epic: PUB-01
- Work wave: W2
- Release gate: G2
- Priority: P1
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
