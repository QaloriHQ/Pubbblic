# [PUB-01.07] Instrument marketing-to-app attribution

## Objective
Track anonymous-to-authenticated funnels, acquisition sources, CTA performance, and consent-aware analytics.

## Acceptance criteria
- [ ] Consent preferences are honored before optional event collection.
- [ ] Attribution survives allowed cross-subdomain transitions without exposing PII.
- [ ] Events are reconciled against a documented taxonomy.

## Dependencies (blocked by)
- PUB-01.02
- PUB-10.01

## Execution metadata
- Epic: PUB-01
- Work wave: W5
- Release gate: G2
- Priority: P1
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
