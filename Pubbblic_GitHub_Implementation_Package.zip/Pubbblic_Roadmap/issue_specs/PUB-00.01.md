# [PUB-00.01] Record core ADRs and product contracts

## Objective
Record hybrid account modes, immutable release versions, publisher authorization, verified placements, organization tenancy and the separation of app and worker workloads.

## Acceptance criteria
- [ ] ADRs define explicit permissions for managed, customer-connected, and assisted distribution.
- [ ] State charts distinguish submission, editorial review, and verified publication.
- [ ] Unresolved product decisions have owners and documented launch-default choices.

## Dependencies (blocked by)
- None (foundation-ready)

## Execution metadata
- Epic: PUB-00
- Work wave: W1
- Release gate: G1
- Priority: P0
- Estimate: M (relative sizing)
- Risk: Medium

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
