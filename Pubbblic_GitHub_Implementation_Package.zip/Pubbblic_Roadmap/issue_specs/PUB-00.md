# [PUB-00] Foundation and engineering operations

## Outcome
Define the engineering baseline, environment isolation, source governance, quality gates, and product conventions.
## Release gate
G1
## Child issues (implementation contracts)
- [ ] PUB-00.01: Record core ADRs and product contracts
- [ ] PUB-00.02: Initialize Next.js monorepo and Codespaces
- [ ] PUB-00.03: Configure Vercel staging and production isolation
- [ ] PUB-00.04: Provision Supabase environments and migrations
- [ ] PUB-00.05: Establish CI and branch protection
- [ ] PUB-00.06: Create shared design system and accessibility primitives
- [ ] PUB-00.07: Implement observability and error taxonomy
- [ ] PUB-00.08: Define configuration and secrets governance

## Epic completion conditions
- [ ] All P0 children passed acceptance and merged to staging
- [ ] Evidence and security/privacy review recorded in child issues
- [ ] Relevant release gate explicitly approved; production changes not implied
- [ ] Risks, follow-on tasks and known limitations documented

**Ownership:** Product approval is required for scope changes and every production authorization.
