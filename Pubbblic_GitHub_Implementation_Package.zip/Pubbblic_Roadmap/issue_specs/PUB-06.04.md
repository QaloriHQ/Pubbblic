# [PUB-06.04] Implement submission idempotency and reconciliation

## Objective
Establish stable idempotency keys across campaign-version/destination/account and handle unknown submission outcomes.

## Acceptance criteria
- [ ] Replayed messages do not create a second publication attempt without safe reconciliation.
- [ ] Ambiguous results move to review rather than automatic duplicate form submission.
- [ ] Deduplication survives worker crashes and webhook replay.

## Dependencies (blocked by)
- PUB-06.02

## Execution metadata
- Epic: PUB-06
- Work wave: W4
- Release gate: G4
- Priority: P0
- Estimate: M (relative sizing)
- Risk: High

## Verification evidence required
- [ ] Code/tests or policy artifact linked; acceptance criteria mapped to evidence
- [ ] Unit/integration/e2e test output attached as applicable; staging behavior verified
- [ ] Security/privacy/publisher-permission implications evaluated and documented
- [ ] Documentation, dashboards and migration/runbooks updated when relevant
- [ ] Reviewer records pass/fail and final release gate decision

## Definition of done
Feature is merged through reviewed PR with passing CI, staging verification, and no unapproved external publishing, billing or production enablement. No production launch is authorized by closing this issue.

### Notes
Publisher sites, prices, and automation rights must be revalidated against current contracts. Do not bypass CAPTCHA/MFA, anti-bot restrictions, robots/ToS, or third-party account controls.
