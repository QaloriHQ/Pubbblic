#!/usr/bin/env python3
"""Pubbblic GitHub Projects setup using authenticated `gh` CLI.

Safe default: preview only. Explicit --owner and --apply are required for writes.
Does not start or authorize any publisher distribution.
"""
import argparse
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
BACKLOG = json.loads((HERE / 'issues.json').read_text(encoding='utf-8'))
MILESTONES = json.loads((HERE / 'milestones.json').read_text(encoding='utf-8'))
PROJECT_DEFAULT = 'Pubbblic — Product Roadmap'


def execute(*args, expect_json=False, optional=False, silent=False):
    cmd = ['gh', *map(str,args)]
    p = subprocess.run(cmd, text=True, capture_output=True)
    if p.returncode != 0:
        if optional:
            if not silent:
                print('WARNING:', ' '.join(cmd[:5]), p.stderr.strip()[:250], file=sys.stderr)
            return None
        raise RuntimeError('Command failed: ' + ' '.join(cmd[:7]) + '\n' + p.stderr.strip()[:600])
    if expect_json:
        try:
            return json.loads(p.stdout or '{}')
        except json.JSONDecodeError as e:
            raise RuntimeError('Command did not return JSON: '+' '.join(cmd[:6])) from e
    return p.stdout.strip()


def fetch_project(owner, title):
    data=execute('project','list','--owner',owner,'--limit','100','--format','json',expect_json=True)
    for p in data.get('projects', []):
        if p.get('title') == title:
            return p
    return None


def get_project_number(owner,title):
    p=fetch_project(owner,title)
    if p: return int(p['number']),p.get('url')
    data=execute('project','create','--owner',owner,'--title',title,'--format','json',expect_json=True)
    return int(data['number']),data.get('url')


def create_labels(repo):
    existing={x['name'] for x in execute('label','list','--repo',repo,'--json','name','--limit','1000',expect_json=True)}
    palette={'type:epic':'8250df','type:task':'0969da','priority:p0':'cf222e','priority:p1':'bf8700','priority:p2':'1a7f37',
             'risk:high':'cf222e','risk:medium':'fbca04','risk:low':'2da44e'}
    palette.update({f'area:pub-{i:02d}':'57606a' for i in range(13)})
    for label,color in palette.items():
        if label not in existing:
            execute('label','create',label,'--repo',repo,'--color',color,'--description','Pubbblic roadmap classification')
    print(f'Labels ready: {len(palette)}')


def create_milestones(repo):
    existing=execute('api','-X','GET',f'repos/{repo}/milestones?state=all&per_page=100',expect_json=True)
    have={x['title'] for x in existing}
    by_gate={}
    for row in MILESTONES:
        if row['title'] not in have:
            execute('api','-X','POST',f'repos/{repo}/milestones','-f',f'title={row["title"]}','-f',f'description={row["description"]}')
        by_gate[row['gate']]=row['title']
    print(f'Milestones ready: {len(by_gate)}')
    return by_gate


def create_project_fields(owner,number):
    fields=execute('project','field-list',str(number),'--owner',owner,'--format','json',expect_json=True)
    have={x['name'] for x in fields.get('fields',[])}
    options={'Priority':'P0,P1,P2','Wave':'W1,W2,W3,W4,W5,W6','Risk':'Low,Medium,High',
             'Delivery Stage':'Backlog,Ready,In Progress,In Review,Verification,Blocked,Done',
             'Gate':'G1,G2,G3,G4,G5,G6,G7',
             'Workstream':','.join(f'PUB-{i:02d}' for i in range(13))}
    for name,opts in options.items():
        if name not in have:
            execute('project','field-create',str(number),'--owner',owner,
                    '--name',name,'--data-type','SINGLE_SELECT','--single-select-options',opts)
    print('Project fields ready: Priority, Wave, Risk, Delivery Stage, Gate, Workstream')


def issue_numbers(repo):
    data=execute('issue','list','--repo',repo,'--state','all','--limit','1000','--json','title,number,url',expect_json=True)
    found={}
    for entry in data:
        m=re.match(r'^\[(PUB-\d{2}(?:\.\d{2})?)\]\s',entry.get('title',''))
        if m:
            if m.group(1) in found:raise RuntimeError(f'Duplicate ID already on GitHub: {m.group(1)}')
            found[m.group(1)]=entry
    return found


def render_body(issue, known):
    body=issue['body']
    for dep in issue.get('dependencies',[]):
        if dep in known:
            body=body.replace(f'- {dep}\n',f'- #{known[dep]["number"]}\n')
    if issue['type']=='epic':
        for ch in [i for i in BACKLOG['issues'] if i.get('epic')==issue['id']]:
            if ch['id'] in known:
                body=body.replace(f'- [ ] {ch["id"]}:',f'- [ ] #{known[ch["id"]]["number"]} ({ch["id"]}):')
    return body


def create_issue(repo, issue, known, milestones):
    args=['issue','create','--repo',repo,'--title',issue['full_title'],
          '--milestone',milestones[issue['gate']]]
    for label in issue['labels']:
        args+=['--label',label]
    if issue['type']=='task':
        args+=['--parent',str(known[issue['epic']]['number'])]
        if issue.get('dependencies'):
            missing=[d for d in issue['dependencies'] if d not in known]
            if missing:raise RuntimeError(f'Issue {issue["id"]} blocked by missing {missing}')
            args+=['--blocked-by',','.join(str(known[d]['number']) for d in issue['dependencies'])]
    with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',suffix='.md',delete=False) as temp:
        temp.write(render_body(issue,known)); path=temp.name
    try:
        url=execute(*args,'--body-file',path)
    finally:
        Path(path).unlink(missing_ok=True)
    match=re.search(r'/issues/(\d+)',url)
    if not match:raise RuntimeError('Issue created but could not parse issue number: '+url)
    return {'url':url,'number':int(match.group(1)),'title':issue['full_title']}


def get_existing_project_urls(owner, number):
    """Collect existing project items to avoid duplicate addition on reruns."""
    data=execute('project','item-list',str(number),'--owner',owner,'--limit','1000','--format','json',expect_json=True)
    urls=set()
    for item in data.get('items',[]):
        content=item.get('content') or {}
        if not isinstance(content,dict): content={}
        url=content.get('url') or item.get('contentUrl') or item.get('url')
        if isinstance(url,str): urls.add(url.rstrip('/'))
    return urls


def attach_to_project(owner,number,issue,entry,project_urls):
    url=entry['url']
    if url.rstrip('/') not in project_urls:
        execute('project','item-add',str(number),'--owner',owner,'--url',url)
        project_urls.add(url.rstrip('/'))
    fields=[('Priority',issue.get('priority','P1')),('Wave',issue['wave']),
            ('Risk',issue.get('risk','Medium')),('Gate',issue['gate']),
            ('Workstream',issue['id'][:6])]
    fields.append(('Delivery Stage','Backlog'))
    for field,value in fields:
        # Never reset an existing item's human-managed delivery status on reruns.
        if field=='Delivery Stage' and entry.get('_preexisting_project_item'): continue
        execute('project','item-edit',str(number),'--owner',owner,'--url',url,'--field',field,'--value',value)


def main():
    parser=argparse.ArgumentParser(description='Pubbblic GitHub Project and issue bootstrap (preview by default)')
    parser.add_argument('--owner',required=True,help='Explicit GitHub user/org, e.g. ByMarkAllan or QaloriHQ')
    parser.add_argument('--repo',default='pubbblic-platform',help='Repository name (default: pubbblic-platform)')
    parser.add_argument('--project-title',default=PROJECT_DEFAULT)
    parser.add_argument('--apply',action='store_true',help='Perform GitHub writes (otherwise preview only)')
    parser.add_argument('--existing-only',action='store_true',help='Refuse to create repository if absent')
    parser.add_argument('--skip-project',action='store_true',help='Create issues/milestones but not a GitHub Project')
    parser.add_argument('--limit',type=int,default=0,help='Only create first N issues; 0 for all')
    opt=parser.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9-]+',opt.owner):parser.error('Invalid owner')
    if not re.fullmatch(r'[A-Za-z0-9_.-]+',opt.repo):parser.error('Invalid repository name')
    if opt.limit<0:parser.error('--limit must be >= 0')
    repo=f'{opt.owner}/{opt.repo}'
    issues=BACKLOG['issues'][:opt.limit or None]
    print('Repo:',repo,'Project:',opt.project_title)
    print('Issue count:',len(issues),'of',BACKLOG['total_issues'])
    print('Mode:','APPLY (write)' if opt.apply else 'PREVIEW (no writes)')
    print('Epics:',sum(x['type']=='epic' for x in issues),'Tasks:',sum(x['type']=='task' for x in issues))
    print('Issue IDs:', ', '.join(x['id'] for x in issues[:8]), '...')
    if not opt.apply:
        print('\nTo create remote resources, rerun with --apply after verifying --owner and gh auth permissions.')
        return
    if shutil.which('gh') is None:raise RuntimeError('gh CLI is not installed; install GitHub CLI in Codespaces.')
    version_info=execute('--version')
    match=re.search(r'gh version (\d+)\.(\d+)\.(\d+)',version_info)
    if not match or tuple(map(int,match.groups())) < (2,94,0):
        raise RuntimeError('GitHub CLI 2.94.0+ is required for native sub-issues/dependencies; upgrade gh first.')
    execute('auth','status')
    exists=execute('repo','view',repo,'--json','nameWithOwner',optional=True,silent=True)
    if not exists:
        if opt.existing_only:raise RuntimeError(f'Repository {repo} not found or accessible; --existing-only prevents creation.')
        execute('repo','create',repo,'--private','--add-readme','--description','Pubbblic hybrid press release distribution platform')
        print('Created private repository:',repo)
    else: print('Using existing repository:',repo)
    create_labels(repo)
    milestones=create_milestones(repo)
    project=None
    project_url=None
    if not opt.skip_project:
        project,project_url=get_project_number(opt.owner,opt.project_title)
        execute('project','link',str(project),'--owner',opt.owner,'--repo',repo,optional=True,silent=True)
        create_project_fields(opt.owner,project)
        execute('project','edit',str(project),'--owner',opt.owner,'--description',
                'Pubbblic hybrid press release platform roadmap: authorized connectors, creation, verified distribution, commerce, governance.',optional=True,silent=True)
        print('GitHub Project:',project_url or f'owner={opt.owner}, number={project}')
    known=issue_numbers(repo)
    project_urls=get_existing_project_urls(opt.owner,project) if project is not None else set()
    created=0
    for idx,issue in enumerate(issues,1):
        key=issue['id']
        if key in known:
            entry=known[key]
            status='exists'
        else:
            entry=create_issue(repo,issue,known,milestones)
            known[key]=entry
            created+=1
            status='created'
        if project is not None:
            entry=dict(entry)
            entry['_preexisting_project_item']=entry['url'].rstrip('/') in project_urls
            attach_to_project(opt.owner,project,issue,entry,project_urls)
        print(f'[{idx:03d}/{len(issues):03d}] {status:7s} {key} {entry["url"]}',flush=True)
    print(f'\nCOMPLETE: {created} new issues; {len(issues)-created} reused. Repo: https://github.com/{repo}')
    if project is not None:print('View project:',project_url or f'gh project view {project} --owner {opt.owner} --web')
    print('No external publisher automation, payment processing or production flags were enabled.')

if __name__=='__main__':
    try:main()
    except Exception as exc:
        print('ERROR:',exc,file=sys.stderr)
        sys.exit(1)
