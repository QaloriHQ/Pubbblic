# Pubbblic architecture and operating model

## System boundary

- **Monorepo** (`pubbblic-platform` proposed): `apps/marketing` (Next.js), `apps/platform` (Next.js), `apps/worker` (Node + Puppeteer), `packages/ui`, `packages/domain`, `packages/connectors`, `packages/config`, `supabase/migrations`, `tests/`.
- **Hosting**: public and application Next.js workloads on separate Vercel projects/environments; external browser workers on isolated container hosting (provider to select; Vercel is not the long-running worker default).
- **Persistence**: Supabase Postgres + RLS for authoritative data; Supabase Auth for account identity; Supabase Storage for media/evidence; Supabase pgmq for durable work.
- **Payment**: Stripe checkout, signed webhooks, immutable credit and payment ledgers.
- **Product measurement**: Mixpanel for consent-aware journey events; Postgres for financially and operationally authoritative metrics.
- **Governance**: GitHub Projects, typed issues, branch protection, review and production signoffs.

## Hybrid publisher model

| Mode | Account rights | Executor | Condition |
|---|---|---|---|
| Managed/partner | Pubbblic-approved partner agreement explicitly permits agency distribution | Partner API or approved browser connector | Scope, geography, content, rates and contractual permissions valid |
| Customer-connected | Customer owns account and authorizes specified actions; least-privilege access | API/OAuth or specifically authorized browser automation | Customer delegation and publisher ToS both allow automation |
| Assisted | No permission or viable automation integration available | User or authorized operator completes a manual task | Never labeled as auto-published or guaranteed |

An integration is **disabled by default** until publisher authorization has been recorded, reviewed, scoped and associated with a connector version.

## Canonical domain entities

`organizations`, `organization_members`, `brands`, `release_drafts`, `release_versions`, `release_assets`, `editorial_reviews`, `publisher_registry`, `publisher_permissions`, `publisher_connections`, `connector_versions`, `campaigns`, `campaign_destinations`, `submission_attempts`, `submission_events`, `publication_evidence`, `verification_checks`, `manual_action_tasks`, `packages`, `orders`, `credit_ledger`, `refunds`, `audit_events`.

RLS for all customer-owned records; service identity only in narrowly scoped workers; no secrets in client state, logs, images or exports.

## State machine

Release: `draft → in_review → changes_requested/approved/rejected → scheduled/publishing → corrected/withdrawn`. Approved version is immutable; edits create a new revision.

Destination: `selected → eligible → queued → running → submitted → editorial_pending → verification_pending → published_verified`. Exception states include `needs_action`, `blocked`, `rejected`, `failed`, `cancelled`, `unknown_outcome`, `withdrawn`. Never infer `published_verified` from a submit response alone.

## Routing sequence

1. Validate issuer, content policy, approved release version and embargo.
2. Resolve package entitlements and publisher eligibility, permissions, account, geography and current fees.
3. Produce a transparent customer-approved distribution plan and stable per-destination idempotency keys.
4. Execute via partner/API, explicitly authorized Puppeteer, or assisted mode; all with bounded rate limits.
5. Preserve safe confirmation evidence. Reconcile ambiguous results before retrying.
6. Verify live URL and release identity; record evidence grade and subsequent removals.
7. Reconcile commerce, compute evidence-grounded metrics, notify users and generate reports.

## Non-negotiable safeguards

- No blind retries of unknown outcome; duplicate publication prevention across worker crashes and account switches.
- No evasion of CAPTCHAs, MFA, anti-bot controls, Terms of Service or account restrictions.
- Isolated browser contexts, constrained outbound networking, download checks, and encrypted credentials.
- Transparent status/metrics provenance; no guaranteed rankings, backlinks, AI inclusion, audience reach or editorial placements.
- Per-publisher kill switches and logs, legal terms-version reviews, mandatory permission revalidation on material connector changes.
