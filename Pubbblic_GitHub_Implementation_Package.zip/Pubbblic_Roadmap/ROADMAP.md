# Pubbblic — executable product roadmap

**Scope:** 13 epics and 125 implementation issues; 138 total GitHub issues.

**Status:** Prepared for import; not yet created in GitHub. No live publisher automation is authorized or deployed.

## Core delivery decisions

- Hybrid account model: managed partnerships where authorized, customer-connected accounts where both parties allow, assisted submissions otherwise.
- Public `pubbblic.com`; customer `app.pubbblic.com`; two isolated Vercel workloads; browser workers deployed separately.
- Authoritative data: Supabase Postgres/RLS, Auth, Storage and pgmq. Analytics: Mixpanel. Payments: Stripe (proposed).
- No automated external publisher submission without written authorization and no guaranteed media pickup/SEO or AI citations.
- Production activation requires recorded explicit owner approval at G6.

## Epics and execution lanes

| Epic | Workstream | Tasks | Default gate |
|---|---|---:|---|
| PUB-00 | Foundation and engineering operations | 8 | G1 |
| PUB-01 | Brand, marketing and public newsroom | 7 | G2 |
| PUB-02 | Identity, organizations and secure access | 8 | G1 |
| PUB-03 | Press release creation and publishing workflow | 8 | G2 |
| PUB-04 | Editorial integrity, claims and approval | 7 | G2 |
| PUB-05 | Publisher network, permission and commercial contracts | 28 | G3 |
| PUB-06 | Distribution orchestration and scheduling | 9 | G4 |
| PUB-07 | Publisher connector framework and Puppeteer pilot | 9 | G4 |
| PUB-08 | Publication verification and delivery evidence | 8 | G4 |
| PUB-09 | Packages, credits, checkout and revenue protection | 8 | G5 |
| PUB-10 | Customer reporting, Mixpanel and AI visibility | 8 | G5 |
| PUB-11 | Administration, support and compliance operations | 8 | G6 |
| PUB-12 | Quality, UAT and production authorization | 9 | G6 |

## Milestones (gate-oriented)

- **M1 — Foundation (G1):** CI, environments, authentication, RLS, secrets and rollback baseline.
- **M2 — Authoring & Editorial (G2):** Press release creation, human review, marketing and hosted newsroom.
- **M3 — Publisher Authorization (G3):** Hybrid models, 19-site audit and at least one written pilot authorization.
- **M4 — Authorized Distribution Pilot (G4):** Queue, adapter, worker isolation, permitted live pilot and evidence.
- **M5 — Commercial MVP (G5):** Packages, Stripe, transparent delivery and accurate reporting.
- **M6 — Production Launch (G6):** Security, reliability, finance, legal, support and explicit owner go/no-go.
- **M7 — Scale & Intelligence (G7):** Optional AI visibility and network scaling after measured quality.

## Dependency-linked implementation tasks

### PUB-00 — Foundation and engineering operations

- **PUB-00.01** [P0, M, W1] Record core ADRs and product contracts — blocked by: none.
- **PUB-00.02** [P0, L, W1] Initialize Next.js monorepo and Codespaces — blocked by: PUB-00.01.
- **PUB-00.03** [P0, M, W1] Configure Vercel staging and production isolation — blocked by: PUB-00.02.
- **PUB-00.04** [P0, L, W1] Provision Supabase environments and migrations — blocked by: PUB-00.02.
- **PUB-00.05** [P0, M, W1] Establish CI and branch protection — blocked by: PUB-00.02.
- **PUB-00.06** [P1, M, W1] Create shared design system and accessibility primitives — blocked by: PUB-00.02.
- **PUB-00.07** [P0, M, W1] Implement observability and error taxonomy — blocked by: PUB-00.02, PUB-00.04.
- **PUB-00.08** [P0, M, W1] Define configuration and secrets governance — blocked by: PUB-00.03, PUB-00.04.

### PUB-01 — Brand, marketing and public newsroom

- **PUB-01.01** [P1, M, W2] Build original brand and marketing information architecture — blocked by: PUB-00.06.
- **PUB-01.02** [P1, M, W2] Implement conversion-focused marketing pages — blocked by: PUB-01.01, PUB-00.03.
- **PUB-01.04** [P0, M, W3] Launch publicly searchable newsroom — blocked by: PUB-03.07, PUB-04.05.
- **PUB-01.05** [P1, M, W3] Implement technical SEO and structured content — blocked by: PUB-01.04.
- **PUB-01.06** [P0, M, W3] Create content guidelines, privacy and submission terms — blocked by: PUB-04.01, PUB-05.01.
- **PUB-01.03** [P1, M, W5] Publish accurate network and pricing pages — blocked by: PUB-01.01, PUB-05.03, PUB-09.01.
- **PUB-01.07** [P1, M, W5] Instrument marketing-to-app attribution — blocked by: PUB-01.02, PUB-10.01.

### PUB-02 — Identity, organizations and secure access

- **PUB-02.01** [P0, M, W2] Implement Supabase Auth and account onboarding — blocked by: PUB-00.04, PUB-00.06.
- **PUB-02.02** [P0, M, W2] Create organization and membership model — blocked by: PUB-02.01.
- **PUB-02.03** [P0, M, W2] Implement roles and authorization contracts — blocked by: PUB-02.02.
- **PUB-02.04** [P0, L, W2] Apply tenant RLS across all product data — blocked by: PUB-02.03.
- **PUB-02.05** [P1, M, W2] Build agency client and brand workspaces — blocked by: PUB-02.04.
- **PUB-02.06** [P1, M, W2] Add account settings, security sessions and notifications — blocked by: PUB-02.04.
- **PUB-02.08** [P1, M, W2] Design multi-tenant account export and deletion — blocked by: PUB-02.04.
- **PUB-02.07** [P1, M, W3] Implement organization-level approval configuration — blocked by: PUB-02.03, PUB-04.02.

### PUB-03 — Press release creation and publishing workflow

- **PUB-03.01** [P0, M, W3] Define release content schema and validation — blocked by: PUB-00.04, PUB-02.04.
- **PUB-03.02** [P0, L, W3] Build autosave rich-text release editor — blocked by: PUB-03.01, PUB-00.06.
- **PUB-03.03** [P1, M, W3] Create company boilerplates and media contacts — blocked by: PUB-02.05, PUB-03.01.
- **PUB-03.04** [P1, M, W3] Build press release template gallery — blocked by: PUB-03.02.
- **PUB-03.05** [P0, M, W3] Implement media asset pipeline — blocked by: PUB-03.01, PUB-02.04.
- **PUB-03.06** [P0, M, W3] Build version history, compare and restore — blocked by: PUB-03.02.
- **PUB-03.07** [P1, M, W3] Build release previews and shareable proofs — blocked by: PUB-03.06, PUB-03.05.
- **PUB-03.08** [P0, M, W3] Implement scheduling and timezone handling — blocked by: PUB-03.06, PUB-04.02.

### PUB-04 — Editorial integrity, claims and approval

- **PUB-04.01** [P0, M, W3] Define editorial policies and prohibited content — blocked by: PUB-00.01.
- **PUB-04.02** [P0, L, W3] Build editorial state machine and approval queue — blocked by: PUB-03.01, PUB-04.01.
- **PUB-04.03** [P0, M, W3] Add automated content integrity checks — blocked by: PUB-04.02, PUB-03.05.
- **PUB-04.04** [P0, M, W3] Implement issuer identity and authorization review — blocked by: PUB-02.05, PUB-04.01.
- **PUB-04.05** [P0, M, W3] Build approved release publishing and corrections — blocked by: PUB-04.02, PUB-03.06.
- **PUB-04.06** [P1, M, W3] Build moderation case management — blocked by: PUB-04.03, PUB-04.04.
- **PUB-04.07** [P0, M, W3] Create editorial quality UAT suite — blocked by: PUB-04.03, PUB-04.05.

### PUB-05 — Publisher network, permission and commercial contracts

- **PUB-05.01** [P0, L, W3] Build publisher compliance and outreach audit — blocked by: PUB-00.01.
- **PUB-05.02** [P0, M, W3] Define hybrid account authorization contract — blocked by: PUB-05.01, PUB-02.03.
- **PUB-05.03** [P0, M, W3] Create publisher registry, capabilities and pricing — blocked by: PUB-05.01, PUB-00.04.
- **PUB-05.04** [P0, M, W3] Design permissions and connection onboarding — blocked by: PUB-05.02, PUB-00.08.
- **PUB-05.05** [P1, M, W3] Build publisher network directory and selection UI — blocked by: PUB-05.03, PUB-00.06.
- **PUB-05.06** [P1, M, W3] Implement publisher terms/health monitoring — blocked by: PUB-05.03, PUB-00.07.
- **PUB-05.07** [P0, M, W3] Establish pilot publisher written authorization — blocked by: PUB-05.01, PUB-05.02.
- **PUB-05.08** [P1, M, W5] Add publisher operational scorecard — blocked by: PUB-05.03, PUB-08.03.
- **PUB-05.09** [P0, S, W3] Audit publisher: PRLog — blocked by: PUB-05.01.
- **PUB-05.10** [P0, S, W3] Audit publisher: PR.com — blocked by: PUB-05.01.
- **PUB-05.11** [P0, S, W3] Audit publisher: NewswireToday — blocked by: PUB-05.01.
- **PUB-05.12** [P0, S, W3] Audit publisher: 1888PressRelease — blocked by: PUB-05.01.
- **PUB-05.13** [P1, S, W3] Audit publisher: OpenPR — blocked by: PUB-05.01.
- **PUB-05.14** [P1, S, W3] Audit publisher: PR-Inside — blocked by: PUB-05.01.
- **PUB-05.15** [P1, S, W3] Audit publisher: Online PR News — blocked by: PUB-05.01.
- **PUB-05.16** [P1, S, W3] Audit publisher: PRFire — blocked by: PUB-05.01.
- **PUB-05.17** [P1, S, W3] Audit publisher: PRZoom — blocked by: PUB-05.01.
- **PUB-05.18** [P1, S, W3] Audit publisher: PRWirePro — blocked by: PUB-05.01.
- **PUB-05.19** [P1, S, W3] Audit publisher: PRUrgent — blocked by: PUB-05.01.
- **PUB-05.20** [P1, S, W3] Audit publisher: Express Press Release Distribution — blocked by: PUB-05.01.
- **PUB-05.21** [P1, S, W3] Audit publisher: PRFree — blocked by: PUB-05.01.
- **PUB-05.22** [P1, S, W3] Audit publisher: PRWire Australia — blocked by: PUB-05.01.
- **PUB-05.23** [P1, S, W3] Audit publisher: PRWire India — blocked by: PUB-05.01.
- **PUB-05.24** [P1, S, W3] Audit publisher: Free Press Release Center — blocked by: PUB-05.01.
- **PUB-05.25** [P1, S, W3] Audit publisher: Press Release Power — blocked by: PUB-05.01.
- **PUB-05.26** [P1, S, W3] Audit publisher: PRSync — blocked by: PUB-05.01.
- **PUB-05.27** [P1, S, W3] Audit publisher: PRBD — blocked by: PUB-05.01.
- **PUB-05.28** [P0, M, W3] Consolidate candidate publisher audit and MVP shortlist — blocked by: PUB-05.09, PUB-05.10, PUB-05.11, PUB-05.12, PUB-05.13, PUB-05.14, PUB-05.15, PUB-05.16, PUB-05.17, PUB-05.18, PUB-05.19, PUB-05.20, PUB-05.21, PUB-05.22, PUB-05.23, PUB-05.24, PUB-05.25, PUB-05.26, PUB-05.27, PUB-05.07.

### PUB-06 — Distribution orchestration and scheduling

- **PUB-06.01** [P0, M, W4] Define campaign and destination state machines — blocked by: PUB-00.01, PUB-05.03.
- **PUB-06.02** [P0, L, W4] Implement durable queue and task leasing — blocked by: PUB-00.04, PUB-00.07, PUB-06.01.
- **PUB-06.03** [P0, M, W4] Build eligibility routing and execution plans — blocked by: PUB-05.03, PUB-05.04, PUB-06.01.
- **PUB-06.04** [P0, M, W4] Implement submission idempotency and reconciliation — blocked by: PUB-06.02.
- **PUB-06.05** [P0, M, W4] Build publish scheduling and embargo enforcement — blocked by: PUB-03.08, PUB-06.02.
- **PUB-06.06** [P0, M, W4] Add publisher concurrency and rate controls — blocked by: PUB-06.02, PUB-05.06.
- **PUB-06.07** [P1, M, W4] Create submission activity and event timeline — blocked by: PUB-06.01, PUB-02.04.
- **PUB-06.08** [P0, M, W4] Implement retry budgets and human escalation — blocked by: PUB-06.04, PUB-06.06.
- **PUB-06.09** [P0, M, W4] Build distribution integration test harness — blocked by: PUB-06.04, PUB-06.08.

### PUB-07 — Publisher connector framework and Puppeteer pilot

- **PUB-07.01** [P0, M, W4] Define typed publisher adapter SDK — blocked by: PUB-05.02, PUB-06.01.
- **PUB-07.02** [P0, L, W4] Provision isolated Puppeteer worker runtime — blocked by: PUB-00.08, PUB-06.02.
- **PUB-07.03** [P0, M, W4] Build secrets and session broker — blocked by: PUB-05.04, PUB-07.02.
- **PUB-07.04** [P0, L, W4] Implement approved browser connector pilot — blocked by: PUB-05.07, PUB-07.01, PUB-07.02, PUB-07.03.
- **PUB-07.05** [P1, M, W4] Implement API/partner connector reference — blocked by: PUB-07.01, PUB-07.03.
- **PUB-07.06** [P0, M, W4] Build assisted submission workspace — blocked by: PUB-07.01, PUB-06.08.
- **PUB-07.07** [P1, M, W4] Implement connector selector/version drift alerts — blocked by: PUB-07.04, PUB-07.05.
- **PUB-07.08** [P0, M, W4] Harden browser worker against untrusted content — blocked by: PUB-07.02, PUB-00.08.
- **PUB-07.09** [P0, L, W5] Run authorized end-to-end publisher pilot — blocked by: PUB-07.04, PUB-07.06, PUB-07.08, PUB-08.03.

### PUB-08 — Publication verification and delivery evidence

- **PUB-08.01** [P0, M, W5] Define placement evidence model and trust levels — blocked by: PUB-06.01, PUB-07.01.
- **PUB-08.02** [P0, M, W5] Build external URL safety and normalization — blocked by: PUB-08.01, PUB-07.08.
- **PUB-08.03** [P0, L, W5] Implement verification service and publication matching — blocked by: PUB-08.01, PUB-08.02.
- **PUB-08.04** [P0, M, W5] Capture confirmation evidence and audit receipts — blocked by: PUB-08.01, PUB-03.05.
- **PUB-08.05** [P1, M, W5] Build re-verification and takedown detection — blocked by: PUB-08.03, PUB-06.02.
- **PUB-08.06** [P0, M, W5] Create customer delivery report and proof bundle — blocked by: PUB-08.03, PUB-08.04.
- **PUB-08.07** [P1, M, W5] Implement customer correction and dispute workflow — blocked by: PUB-08.06, PUB-04.05.
- **PUB-08.08** [P0, M, W5] Build independent verification regression fixtures — blocked by: PUB-08.03, PUB-08.05.

### PUB-09 — Packages, credits, checkout and revenue protection

- **PUB-09.01** [P0, M, W5] Define package catalog and unit economics — blocked by: PUB-05.03, PUB-00.01.
- **PUB-09.02** [P0, L, W5] Integrate Stripe customer and checkout flows — blocked by: PUB-09.01, PUB-02.04.
- **PUB-09.03** [P0, M, W5] Build verified webhook processing and ledgers — blocked by: PUB-09.02.
- **PUB-09.04** [P0, M, W5] Gate dispatch on financial entitlement — blocked by: PUB-09.03, PUB-06.03.
- **PUB-09.05** [P1, M, W5] Implement credits, usage and agency billing — blocked by: PUB-09.03, PUB-02.05.
- **PUB-09.06** [P0, M, W5] Define partial failure, cancellation and refund policies — blocked by: PUB-09.04, PUB-08.06.
- **PUB-09.07** [P0, M, W5] Add taxes, billing identity and compliance review — blocked by: PUB-09.02, PUB-01.06.
- **PUB-09.08** [P1, M, W5] Implement financial reconciliation dashboard — blocked by: PUB-09.03, PUB-09.06.

### PUB-10 — Customer reporting, Mixpanel and AI visibility

- **PUB-10.01** [P0, M, W5] Define event taxonomy and consent policy — blocked by: PUB-00.01, PUB-02.01.
- **PUB-10.02** [P0, M, W5] Instrument critical release conversion funnel — blocked by: PUB-10.01, PUB-06.01.
- **PUB-10.03** [P0, M, W5] Create customer campaign overview dashboard — blocked by: PUB-06.07, PUB-08.03.
- **PUB-10.04** [P0, M, W5] Implement publisher/source metric provenance — blocked by: PUB-08.03, PUB-10.03.
- **PUB-10.05** [P1, M, W5] Build downloadable reports and agency branding — blocked by: PUB-08.06, PUB-02.05.
- **PUB-10.06** [P2, M, W5] Build baseline AI visibility measurement experiment — blocked by: PUB-10.04.
- **PUB-10.07** [P1, M, W5] Create Mixpanel launch dashboards and cohort analysis — blocked by: PUB-10.02, PUB-09.03.
- **PUB-10.08** [P1, M, W5] Build campaign performance and service SLO exports — blocked by: PUB-10.03, PUB-00.07.

### PUB-11 — Administration, support and compliance operations

- **PUB-11.01** [P0, M, W6] Build restricted admin control plane — blocked by: PUB-02.04, PUB-06.07.
- **PUB-11.02** [P0, M, W6] Create connector kill switches and incident controls — blocked by: PUB-05.06, PUB-06.06.
- **PUB-11.03** [P1, M, W6] Implement support cases and manual action queues — blocked by: PUB-07.06, PUB-09.06, PUB-11.01.
- **PUB-11.04** [P0, M, W6] Implement security audit logs and retention — blocked by: PUB-11.01, PUB-00.07.
- **PUB-11.05** [P0, M, W6] Create vulnerability, dependency and browser patch cadence — blocked by: PUB-00.05, PUB-07.02.
- **PUB-11.06** [P1, M, W6] Build privacy rights and compliance response runbooks — blocked by: PUB-02.08, PUB-01.06.
- **PUB-11.07** [P1, M, W6] Write customer incident communication and status page — blocked by: PUB-11.02, PUB-11.03.
- **PUB-11.08** [P0, M, W6] Create abuse prevention and operational rate limiting — blocked by: PUB-04.06, PUB-02.01.

### PUB-12 — Quality, UAT and production authorization

- **PUB-12.01** [P0, L, W6] Build end-to-end happy-path acceptance test — blocked by: PUB-02.04, PUB-04.07, PUB-07.09, PUB-09.04, PUB-10.03.
- **PUB-12.02** [P0, M, W6] Run tenant isolation and auth penetration review — blocked by: PUB-02.08, PUB-07.08, PUB-11.04.
- **PUB-12.03** [P0, M, W6] Run payments and refund UAT matrix — blocked by: PUB-09.06, PUB-09.07, PUB-09.08.
- **PUB-12.04** [P0, L, W6] Run resilience, load and worker crash exercises — blocked by: PUB-06.09, PUB-07.09, PUB-11.02.
- **PUB-12.05** [P0, M, W6] Verify backups, restore and disaster recovery — blocked by: PUB-00.04, PUB-11.04.
- **PUB-12.07** [P0, M, W6] Complete accessibility and mobile QA — blocked by: PUB-01.02, PUB-03.02, PUB-10.03.
- **PUB-12.08** [P0, M, W6] Prepare launch monitoring, rollback and support — blocked by: PUB-11.07, PUB-10.08, PUB-12.04.
- **PUB-12.06** [P0, M, W6] Complete legal and publisher authorization signoff — blocked by: PUB-05.07, PUB-05.28, PUB-01.06, PUB-09.07.
- **PUB-12.09** [P0, M, W6] Obtain explicit production launch authorization — blocked by: PUB-12.01, PUB-12.02, PUB-12.03, PUB-12.05, PUB-12.06, PUB-12.07, PUB-12.08.

## Delivery methodology

Issue states: **Backlog → Ready → In Progress → In Review → Verification → Done**; **Blocked** is an exception with dated resolution plan. Closing a GitHub issue never grants deployment or external submission permission.

Definition of Ready: requirements/acceptance clear; upstream dependencies delivered; product/publisher/legal review for high-risk changes; owner assigned; test plan; staging environment available.

Definition of Done: reviewed PR, passing CI, negative-path and RLS tests where relevant, staging evidence, documentation, operations handoff, approved milestone/gate; no automatic production deployment.

GitHub Project custom fields: `Status`, `Priority (P0/P1/P2)`, `Wave (W1–W6)`, `Risk (Low/Medium/High)`; optional `Area`, `Size`, `Gate`, and `Owner` for manual refinement.

Recommended saved views: Board by Status, Roadmap by Wave, P0 Launch Blockers, Publisher Permission Audit, Connector Health, Verification Queue, Payments & Legal, Sprint/Iteration.

## Pilot publisher selection checklist

- Publicly identified candidate publisher, exact submission endpoint and applicable governing terms.
- Written publisher authorization for proposed account ownership and automation mode (not inferred from form accessibility).
- Confirmed billing, plan, content/media, MFA, rate limits and editorial flow.
- Sandbox/test pathway and documented permission to run controlled tests.
- Ability to capture legitimate confirmation and verify publication without restricted scraping.
- Operable cancellation, corrections, and support contacts.

## Critical path

`PUB-00.01 → PUB-00.02 → PUB-00.04 → PUB-02.04 → PUB-03.01 → PUB-04.02 → PUB-03.08 → PUB-06.05` (content and schedule)

`PUB-05.01 → PUB-05.02 → PUB-05.07 → PUB-07.04 → PUB-07.09 → PUB-12.01 → PUB-12.09` (authorized distribution)

`PUB-06.01 → PUB-06.02 → PUB-06.04 → PUB-06.09 → PUB-12.04 → PUB-12.08 → PUB-12.09` (reliable orchestration)

`PUB-09.01 → PUB-09.02 → PUB-09.03 → PUB-09.06 → PUB-12.03 → PUB-12.09` (commerce)

See `GATES.md` for hard go/no-go and `ARCHITECTURE.md` for boundaries and invariants.
