"""Offline validation for the Pubbblic GitHub import package."""
import csv
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
raw = json.loads((ROOT / 'issues.json').read_text(encoding='utf-8'))
issues = raw['issues']
assert raw['total_issues'] == len(issues), 'Issue count mismatch'
assert len({x['id'] for x in issues}) == len(issues), 'Duplicate canonical IDs'
assert sum(x['type'] == 'epic' for x in issues) == 13, 'Expected 13 epics'
assert sum(x['type'] == 'task' for x in issues) == 125, 'Expected 125 tasks'
seen = set()
ids = {x['id'] for x in issues}
for issue in issues:
    id_ = issue['id']
    assert set(issue.get('dependencies', [])) <= seen, (id_, 'not in topological order')
    assert issue['gate'] in {f'G{i}' for i in range(1, 8)}, id_
    assert issue['wave'] in {f'W{i}' for i in range(1, 7)}, id_
    if issue['type'] == 'task':
        assert issue['priority'] in {'P0', 'P1', 'P2'}, id_
        assert issue['risk'] in {'High', 'Medium', 'Low'}, id_
    assert issue['body'].strip().startswith('## '), id_
    assert (ROOT / 'issue_specs' / f'{id_}.md').is_file(), ('Missing issue spec', id_)
    if issue['type'] == 'task':
        assert issue['epic'] in ids, (id_, 'Missing parent')
    seen.add(id_)
assert len(list((ROOT / 'issue_specs').glob('PUB-*.md'))) == len(issues), 'Issue spec mismatch'
assert len([x for x in issues if x['id'].startswith('PUB-05.') and x['title'].startswith('Audit publisher:')]) == 19, '19 publisher audits missing'
with (ROOT / 'issues.csv').open(newline='', encoding='utf-8') as f:
    csv_count = sum(1 for _ in csv.DictReader(f))
assert csv_count == len(issues), 'CSV mismatch'
print(f'PASS: {len(issues)} issues ({Counter(x["type"] for x in issues)}), 19 publisher audits, acyclic ordered dependencies, valid issue specs/CSV')
