# Pubbblic — GitHub Projects configuration

**Remote status:** Not yet created. Apply using `bootstrap_github.py` in an authenticated Codespace after selecting `--owner`.

## Project and repository

- Project: **Pubbblic — Product Roadmap** (private during MVP)
- Repository: **OWNER/pubbblic-platform** (private)
- Tracking: all 13 epics and 125 task issues, one canonical issue per `PUB-XX.XX` ID
- Issue hierarchy: 13 parent epics + GitHub native sub-issues
- Dependency relations: native **blocked by** links, in addition to explicit issue-body dependency identifiers
- Project Status/Delivery Stage is not the same as production approval; a Done issue is *not* a deploy authorization.

## Project fields

| Field | Type | Values | Use |
|---|---|---|---|
| Delivery Stage | Single select | Backlog, Ready, In Progress, In Review, Verification, Blocked, Done | Primary workflow |
| Priority | Single select | P0, P1, P2 | P0 always visible in launch-blocker view |
| Wave | Single select | W1, W2, W3, W4, W5, W6 | Relative sequencing; not calendar commitments |
| Gate | Single select | G1 through G7 | Milestone readiness |
| Risk | Single select | Low, Medium, High | Triage |
| Workstream | Single select | PUB-00 through PUB-12 | Functional owner grouping |
| Status | GitHub native (if available) | Project defaults | Can be retained alongside Delivery Stage |
| Assignees | GitHub native | Individuals | One implementation owner, independent verifier |
| Milestone | GitHub issue field | M1 through M7 | Releases/gates |

The bootstrap script creates the custom select fields and sets values, leaving **Delivery Stage** unchanged for already imported project items on reruns. GitHub Projects views and per-field color styling should be completed in the web UI, since project view automation is not part of the supplied script.

## Saved views to configure in the GitHub Project UI

| View | Type | Filter / grouping | Audience |
|---|---|---|---|
| Delivery board | Board | Group by Delivery Stage; order by Priority | Team |
| Epic portfolio | Table | `label:type:epic` | Product owner |
| Roadmap | Roadmap or table | Group by Wave; add target dates only after estimation | Product + engineering |
| P0 launch blockers | Table | `label:priority:p0` AND not done | Release owners |
| Publisher authorization | Table | Workstream PUB-05; filter High risk | Partnerships + legal |
| Connector execution | Board | Workstream PUB-06 or PUB-07 or PUB-08 | Engineering + QA |
| Finance and legal | Table | PUB-09 + PUB-12 compliance work | Finance + legal |
| Verification queue | Table | Delivery Stage Verification | QA and approvers |

## Approval and ownership conventions

- **Product owner:** sets scope, accepts change requests, signs final production gate G6.
- **Tech lead:** chooses architecture, approves migrations/API contracts and signs engineering gates.
- **Security owner:** reviews RLS, isolation, credential handling, outbound browser exposure and audit evidence.
- **Publisher partnerships/legal:** records and approves each publisher automation authorization in an evidence-backed registry.
- **Editorial lead:** approves content policy and operational review rules.
- **Finance owner:** signs ledger reconciliation, payment/refund terms, and Stripe production enablement.
- **QA owner:** independently verifies acceptance tests and production readiness evidence.

Avoid making a single person the author, implementer, tester and approver on high-risk work.

## Branching and environments

- `main`: protected production candidate branch; no direct pushes, required PR reviews, mandatory CI checks.
- `staging`: integration branch; deployed to separate staging Vercel targets and Supabase project.
- Feature branches: `feat/PUB-XX.XX-short-description`; references issue in PR.
- Environment gates: staging migration and E2E validation precede main merge; production DB migration is separately approved; production web, worker, billing and publisher flags are individually controlled.
- Worker browser runtime stays separate from Vercel's customer-facing web application.
- Build assets and GitHub Actions logs must never embed publisher credentials or sensitive release drafts.

## Event and financial source of truth

- Supabase Postgres remains authoritative for editorial, distribution, payment and evidence state.
- Mixpanel is an analytics sink, not a transaction ledger and not publication evidence.
- Payment webhooks are signature-validated and idempotent before allocating entitlements or credits.

## Decision records required before coding

1. Legal operating entity and initial customer jurisdiction(s).
2. Verified publisher account/automation authorization model per integration.
3. Initial fee model and refund/partial-failure matrix.
4. Worker hosting and external navigation security model.
5. Data retention/privacy commitments and storage region.
6. Exact definition of a verified placement, correction and removal.
7. Accessibility, reliability and support targets.

## Automation rules

- Imported tasks default to **Backlog**.
- Move to **Ready** only when dependency issues are complete and written acceptance/tests are actionable.
- **In Review** requires a GitHub PR; **Verification** requires a deployed staging artifact and evidence attached to issue.
- **Done** is permitted only after a reviewer signs off on the acceptance checklist.
- Release flags must not be enabled simply from moving an item to Done.
- Any connector authorization lapse automatically forces corresponding publisher destinations to a blocked state.
